export interface Database {
  public: {
    Tables: {
      content: {
        Row: {
          id: string
          title: string
          description: string | null
          content_type: "article" | "video" | "audio" | "image" | "document"
          content_url: string | null
          content_body: string | null
          thumbnail_url: string | null
          is_free: boolean
          price: number
          author_id: string
          category: string | null
          tags: string[] | null
          status: "draft" | "published" | "archived"
          view_count: number
          like_count: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          title: string
          description?: string | null
          content_type: "article" | "video" | "audio" | "image" | "document"
          content_url?: string | null
          content_body?: string | null
          thumbnail_url?: string | null
          is_free?: boolean
          price?: number
          author_id: string
          category?: string | null
          tags?: string[] | null
          status?: "draft" | "published" | "archived"
          view_count?: number
          like_count?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          title?: string
          description?: string | null
          content_type?: "article" | "video" | "audio" | "image" | "document"
          content_url?: string | null
          content_body?: string | null
          thumbnail_url?: string | null
          is_free?: boolean
          price?: number
          author_id?: string
          category?: string | null
          tags?: string[] | null
          status?: "draft" | "published" | "archived"
          view_count?: number
          like_count?: number
          created_at?: string
          updated_at?: string
        }
      }
      user_profiles: {
        Row: {
          id: string
          full_name: string | null
          avatar_url: string | null
          bio: string | null
          role: "user" | "creator" | "admin"
          subscription_tier: "free" | "basic" | "premium" | "vip"
          total_spent: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          role?: "user" | "creator" | "admin"
          subscription_tier?: "free" | "basic" | "premium" | "vip"
          total_spent?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          full_name?: string | null
          avatar_url?: string | null
          bio?: string | null
          role?: "user" | "creator" | "admin"
          subscription_tier?: "free" | "basic" | "premium" | "vip"
          total_spent?: number
          created_at?: string
          updated_at?: string
        }
      }
      paid_cards: {
        Row: {
          id: string
          content_id: string
          user_id: string
          purchase_date: string
          expiry_date: string | null
          access_level: "basic" | "premium" | "vip"
          is_active: boolean
        }
        Insert: {
          id?: string
          content_id: string
          user_id: string
          purchase_date?: string
          expiry_date?: string | null
          access_level?: "basic" | "premium" | "vip"
          is_active?: boolean
        }
        Update: {
          id?: string
          content_id?: string
          user_id?: string
          purchase_date?: string
          expiry_date?: string | null
          access_level?: "basic" | "premium" | "vip"
          is_active?: boolean
        }
      }
      orders: {
        Row: {
          id: string
          user_id: string
          content_id: string
          order_number: string
          amount: number
          currency: string
          status: "pending" | "completed" | "failed" | "refunded"
          payment_method: string | null
          payment_intent_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          content_id: string
          order_number: string
          amount: number
          currency?: string
          status?: "pending" | "completed" | "failed" | "refunded"
          payment_method?: string | null
          payment_intent_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          content_id?: string
          order_number?: string
          amount?: number
          currency?: string
          status?: "pending" | "completed" | "failed" | "refunded"
          payment_method?: string | null
          payment_intent_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
