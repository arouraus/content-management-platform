"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { CreditCard, Smartphone, Wallet } from "lucide-react"
import { useTranslations } from "next-intl"

interface PaymentMethodSelectorProps {
  selectedMethod: string
  onMethodChange: (method: string) => void
  paymentData: any
  onPaymentDataChange: (data: any) => void
}

export default function PaymentMethodSelector({
  selectedMethod,
  onMethodChange,
  paymentData,
  onPaymentDataChange,
}: PaymentMethodSelectorProps) {
  const t = useTranslations("payment")

  const paymentMethods = [
    {
      id: "credit_card",
      name: t("creditCard"),
      description: t("creditCardDescription"),
      icon: CreditCard,
    },
    {
      id: "alipay",
      name: t("alipay"),
      description: t("alipayDescription"),
      icon: Smartphone,
    },
    {
      id: "wechat_pay",
      name: t("wechatPay"),
      description: t("wechatPayDescription"),
      icon: Wallet,
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-white mb-4">{t("selectPaymentMethod")}</h3>
        <div className="grid gap-4">
          {paymentMethods.map((method) => {
            const Icon = method.icon
            const isSelected = selectedMethod === method.id

            return (
              <Card
                key={method.id}
                className={`cursor-pointer transition-all duration-200 ${
                  isSelected ? "bg-purple-600/20 border-purple-500/50" : "bg-white/5 border-white/10 hover:bg-white/10"
                }`}
                onClick={() => onMethodChange(method.id)}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-center space-x-3">
                    <Icon className="h-6 w-6 text-purple-400" />
                    <div>
                      <CardTitle className="text-white text-base">{method.name}</CardTitle>
                      <CardDescription className="text-gray-300 text-sm">{method.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
              </Card>
            )
          })}
        </div>
      </div>

      {/* Credit Card Form */}
      {selectedMethod === "credit_card" && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white">{t("creditCardInfo")}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="card_number" className="text-white">
                {t("cardNumber")}
              </Label>
              <Input
                id="card_number"
                placeholder="1234 5678 9012 3456"
                value={paymentData.card_number || ""}
                onChange={(e) =>
                  onPaymentDataChange({
                    ...paymentData,
                    card_number: e.target.value
                      .replace(/\s/g, "")
                      .replace(/(.{4})/g, "$1 ")
                      .trim(),
                  })
                }
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                maxLength={19}
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="expiry" className="text-white">
                  {t("expiryDate")}
                </Label>
                <Input
                  id="expiry"
                  placeholder="MM/YY"
                  value={paymentData.expiry || ""}
                  onChange={(e) => {
                    let value = e.target.value.replace(/\D/g, "")
                    if (value.length >= 2) {
                      value = value.substring(0, 2) + "/" + value.substring(2, 4)
                    }
                    onPaymentDataChange({ ...paymentData, expiry: value })
                  }}
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                  maxLength={5}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cvv" className="text-white">
                  CVV
                </Label>
                <Input
                  id="cvv"
                  placeholder="123"
                  value={paymentData.cvv || ""}
                  onChange={(e) =>
                    onPaymentDataChange({ ...paymentData, cvv: e.target.value.replace(/\D/g, "").substring(0, 4) })
                  }
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                  maxLength={4}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="cardholder_name" className="text-white">
                {t("cardholderName")}
              </Label>
              <Input
                id="cardholder_name"
                placeholder={t("cardholderNamePlaceholder")}
                value={paymentData.cardholder_name || ""}
                onChange={(e) => onPaymentDataChange({ ...paymentData, cardholder_name: e.target.value })}
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
              />
            </div>
          </CardContent>
        </Card>
      )}

      {/* QR Code Payment */}
      {(selectedMethod === "alipay" || selectedMethod === "wechat_pay") && (
        <Card className="bg-white/5 border-white/10">
          <CardHeader>
            <CardTitle className="text-white">{t("qrCodePayment")}</CardTitle>
            <CardDescription className="text-gray-300">{t("qrCodeDescription")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-8">
              <div className="w-32 h-32 bg-gray-700 rounded-lg mx-auto mb-4 flex items-center justify-center">
                <span className="text-gray-400">{t("qrCodePlaceholder")}</span>
              </div>
              <p className="text-gray-400 text-sm">{t("qrCodeGeneration")}</p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
