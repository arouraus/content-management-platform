"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useTranslations } from "next-intl"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { Loader2, Save, Eye } from "lucide-react"
import { supabase } from "@/lib/supabase/client"
import AIAssistant from "./ai-assistant"

interface ContentFormProps {
  userId: string
  initialData?: any
  isEditing?: boolean
}

export default function ContentForm({ userId, initialData, isEditing = false }: ContentFormProps) {
  const router = useRouter()
  const t = useTranslations("content.form")
  const tCommon = useTranslations("common")
  const tCategories = useTranslations("content.categories")
  const tStatus = useTranslations("content.status")
  const tMessages = useTranslations("content.messages")

  const [loading, setLoading] = useState(false)
  const [formData, setFormData] = useState({
    title: initialData?.title || "",
    description: initialData?.description || "",
    content_type: initialData?.content_type || "article",
    content_body: initialData?.content_body || "",
    content_url: initialData?.content_url || "",
    thumbnail_url: initialData?.thumbnail_url || "",
    category: initialData?.category || "",
    is_free: initialData?.is_free ?? true,
    price: initialData?.price || 0,
    status: initialData?.status || "draft",
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)

    try {
      const contentData = {
        ...formData,
        author_id: userId,
        price: formData.is_free ? 0 : formData.price,
      }

      let result
      if (isEditing && initialData?.id) {
        result = await supabase.from("content").update(contentData).eq("id", initialData.id).select().single()
      } else {
        result = await supabase.from("content").insert([contentData]).select().single()
      }

      if (result.error) {
        throw result.error
      }

      router.push(`/content/${result.data.id}`)
    } catch (error) {
      console.error("Error saving content:", error)
      alert(isEditing ? tMessages("updateError") : tMessages("createError"))
    } finally {
      setLoading(false)
    }
  }

  const handlePreview = () => {
    // Store form data in localStorage for preview
    localStorage.setItem("contentPreview", JSON.stringify(formData))
    window.open("/content/preview", "_blank")
  }

  return (
    <div className="max-w-7xl mx-auto">
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Form */}
        <div className="lg:col-span-2">
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-white">{isEditing ? t("update") : t("create")}</CardTitle>
              <CardDescription className="text-gray-300">
                {isEditing ? t("updateDescription") : t("createDescription")}
              </CardDescription>
            </CardHeader>

            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Basic Information */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="title" className="text-white">
                      {t("title")} *
                    </Label>
                    <Input
                      id="title"
                      value={formData.title}
                      onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                      placeholder={t("titlePlaceholder")}
                      required
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="content_type" className="text-white">
                      {t("contentType")} *
                    </Label>
                    <Select
                      value={formData.content_type}
                      onValueChange={(value) => setFormData({ ...formData, content_type: value })}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder={t("selectContentType")} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="article">{t("contentTypes.article")}</SelectItem>
                        <SelectItem value="video">{t("contentTypes.video")}</SelectItem>
                        <SelectItem value="audio">{t("contentTypes.audio")}</SelectItem>
                        <SelectItem value="image">{t("contentTypes.image")}</SelectItem>
                        <SelectItem value="document">{t("contentTypes.document")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description" className="text-white">
                    {t("description")}
                  </Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    placeholder={t("descriptionPlaceholder")}
                    rows={3}
                    className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                  />
                </div>

                {/* Content URLs */}
                <div className="grid md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="content_url" className="text-white">
                      {t("contentUrl")}
                    </Label>
                    <Input
                      id="content_url"
                      value={formData.content_url}
                      onChange={(e) => setFormData({ ...formData, content_url: e.target.value })}
                      placeholder={t("contentUrlPlaceholder")}
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="thumbnail_url" className="text-white">
                      {t("previewImage")}
                    </Label>
                    <Input
                      id="thumbnail_url"
                      value={formData.thumbnail_url}
                      onChange={(e) => setFormData({ ...formData, thumbnail_url: e.target.value })}
                      placeholder={t("thumbnailPlaceholder")}
                      className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                    />
                  </div>
                </div>

                {/* Content Body */}
                <div className="space-y-2">
                  <Label htmlFor="content_body" className="text-white">
                    {t("content")}
                  </Label>
                  <Textarea
                    id="content_body"
                    value={formData.content_body}
                    onChange={(e) => setFormData({ ...formData, content_body: e.target.value })}
                    placeholder={t("contentPlaceholder")}
                    rows={12}
                    className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                  />
                </div>

                {/* Category and Pricing */}
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="category" className="text-white">
                      {t("category")}
                    </Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger className="bg-white/5 border-white/10 text-white">
                        <SelectValue placeholder={t("selectCategory")} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="technology">{tCategories("technology")}</SelectItem>
                        <SelectItem value="business">{tCategories("business")}</SelectItem>
                        <SelectItem value="lifestyle">{tCategories("lifestyle")}</SelectItem>
                        <SelectItem value="education">{tCategories("education")}</SelectItem>
                        <SelectItem value="entertainment">{tCategories("entertainment")}</SelectItem>
                        <SelectItem value="health">{tCategories("health")}</SelectItem>
                        <SelectItem value="travel">{tCategories("travel")}</SelectItem>
                        <SelectItem value="food">{tCategories("food")}</SelectItem>
                        <SelectItem value="art">{tCategories("art")}</SelectItem>
                        <SelectItem value="science">{tCategories("science")}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label className="text-white">{t("isPaid")}</Label>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={formData.is_free}
                        onCheckedChange={(checked) => setFormData({ ...formData, is_free: checked })}
                      />
                      <span className="text-gray-300">{formData.is_free ? t("free") : t("paid")}</span>
                    </div>
                  </div>

                  {!formData.is_free && (
                    <div className="space-y-2">
                      <Label htmlFor="price" className="text-white">
                        {t("price")}
                      </Label>
                      <Input
                        id="price"
                        type="number"
                        min="0"
                        step="0.01"
                        value={formData.price}
                        onChange={(e) => setFormData({ ...formData, price: Number.parseFloat(e.target.value) || 0 })}
                        placeholder={t("pricePlaceholder")}
                        className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                      />
                    </div>
                  )}
                </div>

                {/* Status */}
                <div className="space-y-2">
                  <Label htmlFor="status" className="text-white">
                    {t("status")}
                  </Label>
                  <Select
                    value={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger className="bg-white/5 border-white/10 text-white">
                      <SelectValue placeholder={t("selectStatus")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">{tStatus("draft")}</SelectItem>
                      <SelectItem value="published">{tStatus("published")}</SelectItem>
                      <SelectItem value="archived">{tStatus("archived")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between pt-6 border-t border-white/10">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={handlePreview}
                    className="border-white/20 text-white hover:bg-white/10 bg-transparent"
                  >
                    <Eye className="h-4 w-4 mr-2" />
                    {t("preview")}
                  </Button>

                  <div className="flex items-center space-x-4">
                    <Button
                      type="button"
                      variant="ghost"
                      onClick={() => router.back()}
                      className="text-white hover:text-purple-300"
                    >
                      {tCommon("cancel")}
                    </Button>
                    <Button type="submit" disabled={loading} className="bg-purple-600 hover:bg-purple-700 text-white">
                      {loading ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          {tCommon("loading")}
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          {isEditing ? t("update") : t("publish")}
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* AI Assistant Sidebar */}
        <div className="lg:col-span-1">
          <div className="sticky top-6">
            {/* AI Assistant component with form integration */}
            <AIAssistant
              onApplyTitle={(title) => setFormData({ ...formData, title })}
              onApplyDescription={(description) => setFormData({ ...formData, description })}
              onApplyContent={(content) => setFormData({ ...formData, content_body: content })}
              currentTitle={formData.title}
              currentDescription={formData.description}
              currentContent={formData.content_body}
              contentType={formData.content_type}
              category={formData.category}
            />
          </div>
        </div>
      </div>
    </div>
  )
}
