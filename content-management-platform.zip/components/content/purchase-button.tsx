"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"
import PurchaseModal from "./purchase-modal"

interface PurchaseButtonProps {
  content: {
    id: string
    title: string
    price: number
    content_type: string
    thumbnail_url?: string
    description?: string
  }
  userId: string
}

export default function PurchaseButton({ content, userId }: PurchaseButtonProps) {
  const [showModal, setShowModal] = useState(false)

  return (
    <>
      <Button onClick={() => setShowModal(true)} className="bg-yellow-600 hover:bg-yellow-700 text-white">
        <ShoppingCart className="h-4 w-4 mr-2" />
        立即购买
      </Button>

      <PurchaseModal isOpen={showModal} onClose={() => setShowModal(false)} content={content} userId={userId} />
    </>
  )
}
