"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { useTranslations } from "next-intl"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Loader2, CreditCard, Shield, Star, ArrowLeft } from "lucide-react"
import { supabase } from "@/lib/supabase/client"
import PaymentMethodSelector from "@/components/payment/payment-method-selector"

interface PurchaseModalProps {
  isOpen: boolean
  onClose: () => void
  content: {
    id: string
    title: string
    price: number
    content_type: string
    thumbnail_url?: string
    description?: string
  }
  userId: string
}

export default function PurchaseModal({ isOpen, onClose, content, userId }: PurchaseModalProps) {
  const router = useRouter()
  const t = useTranslations("payment.purchase")
  const tCommon = useTranslations("common")
  const tStatus = useTranslations("payment.status")

  const [loading, setLoading] = useState(false)
  const [step, setStep] = useState(1) // 1: Select access level, 2: Payment method, 3: Processing
  const [selectedLevel, setSelectedLevel] = useState("basic")
  const [paymentMethod, setPaymentMethod] = useState("credit_card")
  const [paymentData, setPaymentData] = useState({})

  const accessLevels = [
    {
      value: "basic",
      label: t("basic"),
      description: t("oneTime"),
      multiplier: 1,
      icon: Shield,
      color: "text-blue-400",
    },
    {
      value: "premium",
      label: t("premium"),
      description: t("monthly"),
      multiplier: 1.5,
      icon: Star,
      color: "text-purple-400",
    },
    {
      value: "vip",
      label: t("vip"),
      description: t("lifetime"),
      multiplier: 2.5,
      icon: Star,
      color: "text-yellow-400",
    },
  ]

  const selectedAccessLevel = accessLevels.find((level) => level.value === selectedLevel)
  const finalPrice = content.price * (selectedAccessLevel?.multiplier || 1)

  const validatePaymentData = () => {
    if (paymentMethod === "credit_card") {
      const { card_number, expiry, cvv, cardholder_name } = paymentData
      return card_number && expiry && cvv && cardholder_name
    }
    return true // QR code payments don't need validation at this step
  }

  const handlePurchase = async () => {
    setLoading(true)
    setStep(3)

    try {
      // Simulate payment processing delay
      await new Promise((resolve) => setTimeout(resolve, 2000))

      // Generate order number
      const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

      // Create order
      const { data: order, error: orderError } = await supabase
        .from("orders")
        .insert([
          {
            user_id: userId,
            content_id: content.id,
            order_number: orderNumber,
            amount: finalPrice,
            status: "completed",
            payment_method: paymentMethod,
            payment_intent_id: `pi_${Date.now()}`,
          },
        ])
        .select()
        .single()

      if (orderError) throw orderError

      // Calculate expiry date based on access level
      let expiryDate = null
      if (selectedLevel === "basic") {
        expiryDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
      } else if (selectedLevel === "premium") {
        expiryDate = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000) // 90 days
      }
      // VIP has no expiry (null)

      // Create paid card
      const { error: cardError } = await supabase.from("paid_cards").insert([
        {
          content_id: content.id,
          user_id: userId,
          access_level: selectedLevel,
          expiry_date: expiryDate?.toISOString(),
          is_active: true,
        },
      ])

      if (cardError) throw cardError

      // Create payment record
      await supabase.from("payments").insert([
        {
          order_id: order.id,
          payment_provider: getPaymentProvider(paymentMethod),
          provider_payment_id: `${paymentMethod}_${Date.now()}`,
          amount: finalPrice,
          status: "succeeded",
          metadata: {
            access_level: selectedLevel,
            content_title: content.title,
            payment_method: paymentMethod,
            payment_data: paymentMethod === "credit_card" ? { last4: paymentData.card_number?.slice(-4) } : {},
          },
        },
      ])

      // Update user's total spent
      await supabase.rpc("increment", {
        table_name: "user_profiles",
        row_id: userId,
        column_name: "total_spent",
        increment_value: finalPrice,
      })

      onClose()
      router.push(`/payment/success?order=${order.order_number}`)
      router.refresh()
    } catch (error) {
      console.error("Purchase error:", error)
      alert(t("purchaseError"))
      setStep(2)
    } finally {
      setLoading(false)
    }
  }

  const getPaymentProvider = (method: string) => {
    switch (method) {
      case "credit_card":
        return "stripe"
      case "alipay":
        return "alipay"
      case "wechat_pay":
        return "wechat"
      default:
        return "unknown"
    }
  }

  const resetModal = () => {
    setStep(1)
    setSelectedLevel("basic")
    setPaymentMethod("credit_card")
    setPaymentData({})
    setLoading(false)
  }

  const handleClose = () => {
    resetModal()
    onClose()
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="bg-slate-900 border-white/10 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold">
            {step === 1 && t("title")}
            {step === 2 && t("selectPayment")}
            {step === 3 && t("processing")}
          </DialogTitle>
          <DialogDescription className="text-gray-300">
            {step === 1 && t("selectPlan")}
            {step === 2 && t("completePayment")}
            {step === 3 && t("processingMessage")}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Step 1: Access Level Selection */}
          {step === 1 && (
            <>
              {/* Content Preview */}
              <Card className="bg-white/5 border-white/10">
                <CardHeader>
                  <div className="flex items-start space-x-4">
                    {content.thumbnail_url && (
                      <img
                        src={content.thumbnail_url || "/placeholder.svg"}
                        alt={content.title}
                        className="w-20 h-20 object-cover rounded-lg"
                      />
                    )}
                    <div className="flex-1">
                      <CardTitle className="text-white">{content.title}</CardTitle>
                      <div className="flex items-center space-x-2 mt-2">
                        <Badge variant="secondary" className="bg-purple-600/20 text-purple-300">
                          {content.content_type}
                        </Badge>
                        <span className="text-gray-400">
                          {t("basePrice")}: ¥{content.price}
                        </span>
                      </div>
                      {content.description && (
                        <CardDescription className="text-gray-300 mt-2">{content.description}</CardDescription>
                      )}
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Access Level Selection */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-white">{t("selectPlan")}</h3>
                <div className="grid gap-4">
                  {accessLevels.map((level) => {
                    const Icon = level.icon
                    const isSelected = selectedLevel === level.value
                    const price = content.price * level.multiplier

                    return (
                      <Card
                        key={level.value}
                        className={`cursor-pointer transition-all duration-200 ${
                          isSelected
                            ? "bg-purple-600/20 border-purple-500/50"
                            : "bg-white/5 border-white/10 hover:bg-white/10"
                        }`}
                        onClick={() => setSelectedLevel(level.value)}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-3">
                              <Icon className={`h-5 w-5 ${level.color}`} />
                              <div>
                                <CardTitle className="text-white text-lg">{level.label}</CardTitle>
                                <CardDescription className="text-gray-300">{level.description}</CardDescription>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold text-white">¥{price.toFixed(2)}</div>
                              {level.multiplier !== 1 && (
                                <div className="text-sm text-gray-400">
                                  {level.multiplier}x {t("basePrice")}
                                </div>
                              )}
                            </div>
                          </div>
                        </CardHeader>
                      </Card>
                    )
                  })}
                </div>
              </div>
            </>
          )}

          {/* Step 2: Payment Method */}
          {step === 2 && (
            <>
              <Card className="bg-gradient-to-r from-purple-600/10 to-pink-600/10 border-purple-500/30">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-white">{t("orderSummary")}</CardTitle>
                      <CardDescription className="text-gray-300">
                        {selectedAccessLevel?.label} - {selectedAccessLevel?.description}
                      </CardDescription>
                    </div>
                    <div className="text-3xl font-bold text-white">¥{finalPrice.toFixed(2)}</div>
                  </div>
                </CardHeader>
              </Card>

              <PaymentMethodSelector
                selectedMethod={paymentMethod}
                onMethodChange={setPaymentMethod}
                paymentData={paymentData}
                onPaymentDataChange={setPaymentData}
              />
            </>
          )}

          {/* Step 3: Processing */}
          {step === 3 && (
            <div className="text-center py-12">
              <Loader2 className="h-16 w-16 animate-spin text-purple-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">{t("processing")}</h3>
              <p className="text-gray-400">{t("processingMessage")}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          {step === 1 && (
            <>
              <Button
                variant="outline"
                onClick={handleClose}
                className="border-white/20 text-white hover:bg-white/10 bg-transparent"
              >
                {t("cancel")}
              </Button>
              <Button onClick={() => setStep(2)} className="bg-purple-600 hover:bg-purple-700 text-white">
                {tCommon("next")}
              </Button>
            </>
          )}

          {step === 2 && (
            <>
              <Button
                variant="outline"
                onClick={() => setStep(1)}
                className="border-white/20 text-white hover:bg-white/10 bg-transparent"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                {tCommon("previous")}
              </Button>
              <Button
                onClick={handlePurchase}
                disabled={loading || !validatePaymentData()}
                className="bg-purple-600 hover:bg-purple-700 text-white"
              >
                <CreditCard className="mr-2 h-4 w-4" />
                {t("purchaseButton")} ¥{finalPrice.toFixed(2)}
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
