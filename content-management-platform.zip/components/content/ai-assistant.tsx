"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Loader2, Sparkles, Copy, Check, Wand2, Search, PlusCircle } from "lucide-react"

interface AIAssistantProps {
  onApplyTitle?: (title: string) => void
  onApplyDescription?: (description: string) => void
  onApplyContent?: (content: string) => void
  currentTitle?: string
  currentDescription?: string
  currentContent?: string
  contentType?: string
  category?: string
}

export default function AIAssistant({
  onApplyTitle,
  onApplyDescription,
  onApplyContent,
  currentTitle,
  currentDescription,
  currentContent,
  contentType,
  category,
}: AIAssistantProps) {
  const [loading, setLoading] = useState(false)
  const [activeFeature, setActiveFeature] = useState<string | null>(null)
  const [suggestions, setSuggestions] = useState<string[]>([])
  const [enhancedContent, setEnhancedContent] = useState("")
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null)

  const generateTitles = async () => {
    if (!currentDescription && !currentContent) {
      alert("请先填写描述或内容正文")
      return
    }

    setLoading(true)
    setActiveFeature("titles")
    setSuggestions([])

    try {
      const response = await fetch("/api/ai/generate-title", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          description: currentDescription || currentContent?.substring(0, 200),
          contentType,
          category,
        }),
      })

      if (!response.ok) throw new Error("Failed to generate titles")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullResponse = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value, { stream: true })
          fullResponse += chunk
        }
      }

      // Parse titles from response
      const titleLines = fullResponse
        .split("\n")
        .filter((line) => line.trim() && (line.includes(".") || line.includes("-") || line.includes(":")))
      setSuggestions(titleLines.slice(0, 5))
    } catch (error) {
      console.error("Error generating titles:", error)
      alert("生成标题失败，请重试")
    } finally {
      setLoading(false)
    }
  }

  const generateDescription = async () => {
    if (!currentTitle && !currentContent) {
      alert("请先填写标题或内容正文")
      return
    }

    setLoading(true)
    setActiveFeature("description")
    setEnhancedContent("")

    try {
      const response = await fetch("/api/ai/generate-description", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: currentTitle,
          content: currentContent,
          contentType,
        }),
      })

      if (!response.ok) throw new Error("Failed to generate description")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullResponse = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value, { stream: true })
          fullResponse += chunk
          setEnhancedContent(fullResponse)
        }
      }
    } catch (error) {
      console.error("Error generating description:", error)
      alert("生成描述失败，请重试")
    } finally {
      setLoading(false)
    }
  }

  const enhanceContent = async (type: "improve" | "seo" | "expand") => {
    if (!currentContent) {
      alert("请先填写内容正文")
      return
    }

    setLoading(true)
    setActiveFeature(`enhance-${type}`)
    setEnhancedContent("")

    try {
      const response = await fetch("/api/ai/enhance-content", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          content: currentContent,
          contentType,
          enhancementType: type,
        }),
      })

      if (!response.ok) throw new Error("Failed to enhance content")

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullResponse = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break

          const chunk = decoder.decode(value, { stream: true })
          fullResponse += chunk
          setEnhancedContent(fullResponse)
        }
      }
    } catch (error) {
      console.error("Error enhancing content:", error)
      alert("内容优化失败，请重试")
    } finally {
      setLoading(false)
    }
  }

  const copyToClipboard = async (text: string, index?: number) => {
    try {
      await navigator.clipboard.writeText(text)
      if (typeof index === "number") {
        setCopiedIndex(index)
        setTimeout(() => setCopiedIndex(null), 2000)
      }
    } catch (error) {
      console.error("Failed to copy:", error)
    }
  }

  return (
    <Card className="bg-gradient-to-br from-purple-900/20 to-pink-900/20 border-purple-500/20 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-white flex items-center gap-2">
          <Sparkles className="h-5 w-5 text-purple-400" />
          AI 内容助手
        </CardTitle>
        <CardDescription className="text-gray-300">使用 AI 生成标题、优化内容、创建描述</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Title Generation */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white flex items-center gap-2">
            <Wand2 className="h-4 w-4" />
            标题生成
          </h4>
          <Button
            onClick={generateTitles}
            disabled={loading}
            variant="outline"
            className="w-full border-purple-500/30 text-purple-300 hover:bg-purple-500/10 bg-transparent"
          >
            {loading && activeFeature === "titles" ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                生成中...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                生成标题建议
              </>
            )}
          </Button>

          {suggestions.length > 0 && (
            <div className="space-y-2">
              {suggestions.map((title, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-white/10"
                >
                  <span className="text-white text-sm flex-1">{title}</span>
                  <div className="flex items-center gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(title, index)}
                      className="text-gray-400 hover:text-white"
                    >
                      {copiedIndex === index ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                    {onApplyTitle && (
                      <Button
                        size="sm"
                        onClick={() => onApplyTitle(title)}
                        className="bg-purple-600 hover:bg-purple-700 text-white"
                      >
                        应用
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Description Generation */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white flex items-center gap-2">
            <Search className="h-4 w-4" />
            描述生成
          </h4>
          <Button
            onClick={generateDescription}
            disabled={loading}
            variant="outline"
            className="w-full border-purple-500/30 text-purple-300 hover:bg-purple-500/10 bg-transparent"
          >
            {loading && activeFeature === "description" ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                生成中...
              </>
            ) : (
              <>
                <PlusCircle className="mr-2 h-4 w-4" />
                生成SEO描述
              </>
            )}
          </Button>
        </div>

        {/* Content Enhancement */}
        <div className="space-y-3">
          <h4 className="font-semibold text-white flex items-center gap-2">
            <Wand2 className="h-4 w-4" />
            内容优化
          </h4>
          <div className="grid grid-cols-3 gap-2">
            <Button
              onClick={() => enhanceContent("improve")}
              disabled={loading}
              variant="outline"
              size="sm"
              className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
            >
              {loading && activeFeature === "enhance-improve" ? <Loader2 className="h-3 w-3 animate-spin" /> : "改进"}
            </Button>
            <Button
              onClick={() => enhanceContent("seo")}
              disabled={loading}
              variant="outline"
              size="sm"
              className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
            >
              {loading && activeFeature === "enhance-seo" ? <Loader2 className="h-3 w-3 animate-spin" /> : "SEO优化"}
            </Button>
            <Button
              onClick={() => enhanceContent("expand")}
              disabled={loading}
              variant="outline"
              size="sm"
              className="border-purple-500/30 text-purple-300 hover:bg-purple-500/10"
            >
              {loading && activeFeature === "enhance-expand" ? <Loader2 className="h-3 w-3 animate-spin" /> : "扩展"}
            </Button>
          </div>
        </div>

        {/* Enhanced Content Display */}
        {enhancedContent && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-semibold text-white">AI 生成结果</h4>
              <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">
                {activeFeature === "description" ? "描述" : "内容优化"}
              </Badge>
            </div>
            <div className="relative">
              <Textarea
                value={enhancedContent}
                readOnly
                rows={8}
                className="bg-white/5 border-white/10 text-white resize-none"
              />
              <div className="absolute top-2 right-2 flex gap-2">
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => copyToClipboard(enhancedContent)}
                  className="text-gray-400 hover:text-white"
                >
                  <Copy className="h-4 w-4" />
                </Button>
                {activeFeature === "description" && onApplyDescription && (
                  <Button
                    size="sm"
                    onClick={() => onApplyDescription(enhancedContent)}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    应用
                  </Button>
                )}
                {activeFeature?.startsWith("enhance") && onApplyContent && (
                  <Button
                    size="sm"
                    onClick={() => onApplyContent(enhancedContent)}
                    className="bg-purple-600 hover:bg-purple-700 text-white"
                  >
                    应用
                  </Button>
                )}
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
