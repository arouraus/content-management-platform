"use client"

import { useActionState } from "react"
import { useFormStatus } from "react-dom"
import { useTranslations } from "next-intl"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Mail, Lock, User } from "lucide-react"
import Link from "next/link"
import { signUp } from "@/lib/actions/auth"

function SubmitButton() {
  const { pending } = useFormStatus()
  const t = useTranslations("auth.signup")

  return (
    <Button
      type="submit"
      disabled={pending}
      className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 text-lg font-medium rounded-lg h-[60px]"
    >
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          {t("signupButton")}...
        </>
      ) : (
        t("signupButton")
      )}
    </Button>
  )
}

export default function SignUpForm() {
  const t = useTranslations("auth.signup")
  const [state, formAction] = useActionState(signUp, null)

  return (
    <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
      <CardHeader className="space-y-2 text-center">
        <CardTitle className="text-3xl font-semibold text-white">{t("title")}</CardTitle>
        <CardDescription className="text-lg text-gray-300">{t("subtitle")}</CardDescription>
      </CardHeader>

      <CardContent>
        <form action={formAction} className="space-y-6">
          {state?.error && (
            <div className="bg-red-500/10 border border-red-500/50 text-red-400 px-4 py-3 rounded-lg">
              {t("signupError")}
            </div>
          )}

          {state?.success && (
            <div className="bg-green-500/10 border border-green-500/50 text-green-400 px-4 py-3 rounded-lg">
              {t("signupSuccess")}
            </div>
          )}

          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="fullName" className="block text-sm font-medium text-gray-300">
                {t("fullName")}
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="fullName"
                  name="fullName"
                  type="text"
                  placeholder={t("fullNamePlaceholder")}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 pl-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                {t("email")}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder={t("emailPlaceholder")}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 pl-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                {t("password")}
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder={t("passwordPlaceholder")}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 pl-10"
                />
              </div>
            </div>
          </div>

          <SubmitButton />

          <div className="text-center text-gray-400">
            {t("hasAccount")}{" "}
            <Link href="/auth/login" className="text-purple-400 hover:text-purple-300 hover:underline">
              {t("loginLink")}
            </Link>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
