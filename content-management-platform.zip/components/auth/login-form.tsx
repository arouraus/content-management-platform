"use client"

import { useActionState } from "react"
import { useFormStatus } from "react-dom"
import { useTranslations } from "next-intl"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, Mail, Lock } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import { signIn } from "@/lib/actions/auth"

function SubmitButton() {
  const { pending } = useFormStatus()
  const t = useTranslations("auth.login")

  return (
    <Button
      type="submit"
      disabled={pending}
      className="w-full bg-purple-600 hover:bg-purple-700 text-white py-6 text-lg font-medium rounded-lg h-[60px]"
    >
      {pending ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          {t("loginButton")}...
        </>
      ) : (
        t("loginButton")
      )}
    </Button>
  )
}

export default function LoginForm() {
  const router = useRouter()
  const t = useTranslations("auth.login")
  const [state, formAction] = useActionState(signIn, null)

  // Handle successful login by redirecting
  useEffect(() => {
    if (state?.success) {
      router.push("/dashboard")
    }
  }, [state, router])

  return (
    <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
      <CardHeader className="space-y-2 text-center">
        <CardTitle className="text-3xl font-semibold text-white">{t("title")}</CardTitle>
        <CardDescription className="text-lg text-gray-300">{t("subtitle")}</CardDescription>
      </CardHeader>

      <CardContent>
        <form action={formAction} className="space-y-6">
          {state?.error && (
            <div className="bg-red-500/10 border border-red-500/50 text-red-400 px-4 py-3 rounded-lg">
              {t("loginError")}
            </div>
          )}

          <div className="space-y-4">
            <div className="space-y-2">
              <label htmlFor="email" className="block text-sm font-medium text-gray-300">
                {t("email")}
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="email"
                  name="email"
                  type="email"
                  placeholder={t("emailPlaceholder")}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 pl-10"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label htmlFor="password" className="block text-sm font-medium text-gray-300">
                {t("password")}
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  id="password"
                  name="password"
                  type="password"
                  placeholder={t("passwordPlaceholder")}
                  required
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500 pl-10"
                />
              </div>
            </div>
          </div>

          <SubmitButton />

          <div className="text-center text-gray-400">
            {t("noAccount")}{" "}
            <Link href="/auth/sign-up" className="text-purple-400 hover:text-purple-300 hover:underline">
              {t("signUpLink")}
            </Link>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
