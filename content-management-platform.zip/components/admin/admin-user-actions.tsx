"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { MoreHorizontal, Shield, UserCheck, Ban, Mail } from "lucide-react"
import { supabase } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"

interface AdminUserActionsProps {
  userId: string
  currentRole: string
}

export default function AdminUserActions({ userId, currentRole }: AdminUserActionsProps) {
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const updateUserRole = async (newRole: string) => {
    setLoading(true)
    try {
      const { error } = await supabase.from("user_profiles").update({ role: newRole }).eq("id", userId)

      if (error) throw error

      router.refresh()
    } catch (error) {
      console.error("Error updating user role:", error)
      alert("更新角色失败")
    } finally {
      setLoading(false)
    }
  }

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white" disabled={loading}>
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="bg-gray-800 border-gray-700">
        <DropdownMenuItem className="text-white hover:bg-gray-700">
          <Mail className="h-4 w-4 mr-2" />
          发送邮件
        </DropdownMenuItem>

        <DropdownMenuSeparator className="bg-gray-700" />

        {currentRole !== "admin" && (
          <DropdownMenuItem onClick={() => updateUserRole("admin")} className="text-red-400 hover:bg-gray-700">
            <Shield className="h-4 w-4 mr-2" />
            设为管理员
          </DropdownMenuItem>
        )}

        {currentRole !== "user" && (
          <DropdownMenuItem onClick={() => updateUserRole("user")} className="text-blue-400 hover:bg-gray-700">
            <UserCheck className="h-4 w-4 mr-2" />
            设为普通用户
          </DropdownMenuItem>
        )}

        <DropdownMenuSeparator className="bg-gray-700" />

        <DropdownMenuItem className="text-yellow-400 hover:bg-gray-700">
          <Ban className="h-4 w-4 mr-2" />
          暂停账户
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
