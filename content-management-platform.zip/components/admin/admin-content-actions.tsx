"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
  DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu"
import { Eye, Edit, Trash2, MoreHorizontal, CheckCircle, Archive } from "lucide-react"
import { supabase } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { useTranslations } from "next-intl"

interface AdminContentActionsProps {
  contentId: string
  currentStatus: string
}

export default function AdminContentActions({ contentId, currentStatus }: AdminContentActionsProps) {
  const [loading, setLoading] = useState(false)
  const router = useRouter()
  const t = useTranslations("admin")

  const updateContentStatus = async (newStatus: string) => {
    setLoading(true)
    try {
      const { error } = await supabase.from("content").update({ status: newStatus }).eq("id", contentId)

      if (error) throw error

      router.refresh()
    } catch (error) {
      console.error("Error updating content status:", error)
      alert(t("updateStatusError"))
    } finally {
      setLoading(false)
    }
  }

  const deleteContent = async () => {
    if (!confirm(t("deleteConfirmation"))) return

    setLoading(true)
    try {
      const { error } = await supabase.from("content").delete().eq("id", contentId)

      if (error) throw error

      router.refresh()
    } catch (error) {
      console.error("Error deleting content:", error)
      alert(t("deleteError"))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex items-center gap-2">
      <Button
        size="sm"
        variant="ghost"
        onClick={() => window.open(`/content/${contentId}`, "_blank")}
        className="text-gray-400 hover:text-white"
      >
        <Eye className="h-4 w-4" />
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white" disabled={loading}>
            <MoreHorizontal className="h-4 w-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="bg-gray-800 border-gray-700">
          <DropdownMenuItem
            onClick={() => router.push(`/content/${contentId}/edit`)}
            className="text-white hover:bg-gray-700"
          >
            <Edit className="h-4 w-4 mr-2" />
            {t("editContent")}
          </DropdownMenuItem>

          <DropdownMenuSeparator className="bg-gray-700" />

          {currentStatus !== "published" && (
            <DropdownMenuItem
              onClick={() => updateContentStatus("published")}
              className="text-green-400 hover:bg-gray-700"
            >
              <CheckCircle className="h-4 w-4 mr-2" />
              {t("publishContent")}
            </DropdownMenuItem>
          )}

          {currentStatus !== "draft" && (
            <DropdownMenuItem
              onClick={() => updateContentStatus("draft")}
              className="text-yellow-400 hover:bg-gray-700"
            >
              <Edit className="h-4 w-4 mr-2" />
              {t("setAsDraft")}
            </DropdownMenuItem>
          )}

          {currentStatus !== "archived" && (
            <DropdownMenuItem
              onClick={() => updateContentStatus("archived")}
              className="text-gray-400 hover:bg-gray-700"
            >
              <Archive className="h-4 w-4 mr-2" />
              {t("archiveContent")}
            </DropdownMenuItem>
          )}

          <DropdownMenuSeparator className="bg-gray-700" />

          <DropdownMenuItem onClick={deleteContent} className="text-red-400 hover:bg-gray-700">
            <Trash2 className="h-4 w-4 mr-2" />
            {t("deleteContent")}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}
