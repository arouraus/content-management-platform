import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  const supabase = createClient()

  try {
    const body = await request.json()
    const { event_type, payment_id, status, order_number, metadata } = body

    // Verify webhook signature (in production, you'd verify the actual webhook signature)
    const webhookSecret = process.env.WEBHOOK_SECRET
    const signature = request.headers.get("x-webhook-signature")

    if (!signature || signature !== webhookSecret) {
      return NextResponse.json({ error: "Invalid signature" }, { status: 401 })
    }

    // Find the order
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .select("*")
      .eq("order_number", order_number)
      .single()

    if (orderError || !order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 })
    }

    // Update payment status
    const { error: paymentError } = await supabase
      .from("payments")
      .update({
        status,
        metadata: { ...metadata, webhook_received_at: new Date().toISOString() },
      })
      .eq("provider_payment_id", payment_id)

    if (paymentError) {
      console.error("Error updating payment:", paymentError)
    }

    // Update order status based on payment status
    let orderStatus = order.status
    if (status === "succeeded" && order.status === "pending") {
      orderStatus = "completed"
    } else if (status === "failed") {
      orderStatus = "failed"
    } else if (status === "refunded") {
      orderStatus = "refunded"
    }

    if (orderStatus !== order.status) {
      await supabase.from("orders").update({ status: orderStatus }).eq("id", order.id)

      // If payment succeeded, activate the paid card
      if (orderStatus === "completed") {
        await supabase
          .from("paid_cards")
          .update({ is_active: true })
          .eq("content_id", order.content_id)
          .eq("user_id", order.user_id)
      }

      // If payment failed or refunded, deactivate the paid card
      if (orderStatus === "failed" || orderStatus === "refunded") {
        await supabase
          .from("paid_cards")
          .update({ is_active: false })
          .eq("content_id", order.content_id)
          .eq("user_id", order.user_id)
      }
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
