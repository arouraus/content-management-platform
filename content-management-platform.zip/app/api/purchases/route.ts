import { createClient } from "@/lib/supabase/server"
import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const { searchParams } = new URL(request.url)
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")

  const { data, error, count } = await supabase
    .from("paid_cards")
    .select(`
      *,
      content (
        *,
        user_profiles!content_author_id_fkey (
          full_name,
          avatar_url
        )
      )
    `)
    .eq("user_id", user.id)
    .order("purchase_date", { ascending: false })
    .range((page - 1) * limit, page * limit - 1)

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 })
  }

  return NextResponse.json({
    data,
    pagination: {
      page,
      limit,
      total: count,
      totalPages: Math.ceil((count || 0) / limit),
    },
  })
}

export async function POST(request: NextRequest) {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const { content_id, access_level = "basic" } = await request.json()

    // Check if content exists and is paid
    const { data: content, error: contentError } = await supabase
      .from("content")
      .select("*")
      .eq("id", content_id)
      .single()

    if (contentError || !content) {
      return NextResponse.json({ error: "Content not found" }, { status: 404 })
    }

    if (content.is_free) {
      return NextResponse.json({ error: "Content is free" }, { status: 400 })
    }

    // Check if user already has access
    const { data: existingCard } = await supabase
      .from("paid_cards")
      .select("*")
      .eq("content_id", content_id)
      .eq("user_id", user.id)
      .eq("is_active", true)
      .single()

    if (existingCard) {
      return NextResponse.json({ error: "Already purchased" }, { status: 400 })
    }

    // Calculate price and expiry based on access level
    const multipliers = { basic: 1, premium: 1.5, vip: 2.5 }
    const finalPrice = content.price * (multipliers[access_level as keyof typeof multipliers] || 1)

    let expiryDate = null
    if (access_level === "basic") {
      expiryDate = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
    } else if (access_level === "premium") {
      expiryDate = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000) // 90 days
    }

    // Generate order number
    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`

    // Create order
    const { data: order, error: orderError } = await supabase
      .from("orders")
      .insert([
        {
          user_id: user.id,
          content_id,
          order_number: orderNumber,
          amount: finalPrice,
          status: "completed",
          payment_method: "demo",
        },
      ])
      .select()
      .single()

    if (orderError) throw orderError

    // Create paid card
    const { data: paidCard, error: cardError } = await supabase
      .from("paid_cards")
      .insert([
        {
          content_id,
          user_id: user.id,
          access_level,
          expiry_date: expiryDate?.toISOString(),
          is_active: true,
        },
      ])
      .select()
      .single()

    if (cardError) throw cardError

    // Create payment record
    await supabase.from("payments").insert([
      {
        order_id: order.id,
        payment_provider: "demo",
        provider_payment_id: `demo_${Date.now()}`,
        amount: finalPrice,
        status: "succeeded",
        metadata: {
          access_level,
          content_title: content.title,
        },
      },
    ])

    return NextResponse.json({ success: true, paid_card: paidCard }, { status: 201 })
  } catch (error) {
    console.error("Purchase error:", error)
    return NextResponse.json({ error: "Purchase failed" }, { status: 500 })
  }
}
