import { streamText } from "ai"
import { xai } from "@ai-sdk/xai"
import type { NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { title, content, contentType } = await request.json()

    if (!title && !content) {
      return new Response("Title or content is required", { status: 400 })
    }

    const prompt = `Generate a compelling and SEO-friendly description for this ${contentType}:

Title: ${title || "Not provided"}
Content Preview: ${content ? content.substring(0, 500) + "..." : "Not provided"}

Requirements:
- 120-160 characters for optimal SEO
- Include key benefits and value proposition
- Make it compelling and click-worthy
- Include relevant keywords naturally
- Create urgency or curiosity when appropriate

Generate a perfect meta description:`

    const result = streamText({
      model: xai("grok-3", {
        apiKey: process.env.XAI_API_KEY,
      }),
      prompt: prompt,
      system:
        "You are an expert SEO copywriter. Create compelling meta descriptions that drive clicks and conversions.",
    })

    return result.toTextStreamResponse()
  } catch (error) {
    console.error("Error generating description:", error)
    return new Response("Failed to generate description", { status: 500 })
  }
}
