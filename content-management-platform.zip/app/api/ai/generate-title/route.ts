import { streamText } from "ai"
import { xai } from "@ai-sdk/xai"
import type { NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { description, contentType, category } = await request.json()

    if (!description) {
      return new Response("Description is required", { status: 400 })
    }

    const prompt = `Based on the following content details, generate 5 compelling and SEO-friendly titles:

Content Type: ${contentType || "article"}
Category: ${category || "general"}
Description: ${description}

Requirements:
- Titles should be engaging and click-worthy
- Optimize for SEO with relevant keywords
- Keep titles between 40-60 characters
- Make them specific and valuable to readers
- Vary the style (how-to, listicle, question, etc.)

Generate 5 different title options:`

    const result = streamText({
      model: xai("grok-3", {
        apiKey: process.env.XAI_API_KEY,
      }),
      prompt: prompt,
      system:
        "You are an expert content marketer and SEO specialist. Generate compelling, SEO-optimized titles that drive engagement and clicks.",
    })

    return result.toTextStreamResponse()
  } catch (error) {
    console.error("Error generating titles:", error)
    return new Response("Failed to generate titles", { status: 500 })
  }
}
