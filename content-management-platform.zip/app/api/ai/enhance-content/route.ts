import { streamText } from "ai"
import { xai } from "@ai-sdk/xai"
import type { NextRequest } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { content, contentType, enhancementType } = await request.json()

    if (!content) {
      return new Response("Content is required", { status: 400 })
    }

    let prompt = ""

    switch (enhancementType) {
      case "improve":
        prompt = `Improve and enhance the following ${contentType} content. Make it more engaging, clear, and valuable:

${content}

Please:
- Improve clarity and readability
- Add engaging elements
- Enhance structure and flow
- Make it more compelling
- Keep the original meaning and tone`
        break

      case "seo":
        prompt = `Optimize the following content for SEO while maintaining readability:

${content}

Please:
- Add relevant keywords naturally
- Improve headings and structure
- Enhance meta-friendly content
- Add internal linking suggestions
- Maintain engaging tone`
        break

      case "expand":
        prompt = `Expand and elaborate on the following content with more details, examples, and insights:

${content}

Please:
- Add more depth and detail
- Include relevant examples
- Provide additional insights
- Maintain coherent structure
- Keep the original style`
        break

      default:
        prompt = `Enhance the following content to make it more engaging and valuable:

${content}`
    }

    const result = streamText({
      model: xai("grok-3", {
        apiKey: process.env.XAI_API_KEY,
      }),
      prompt: prompt,
      system:
        "You are an expert content writer and editor. Enhance content while maintaining the author's voice and intent.",
    })

    return result.toTextStreamResponse()
  } catch (error) {
    console.error("Error enhancing content:", error)
    return new Response("Failed to enhance content", { status: 500 })
  }
}
