import { redirect } from "next/navigation"
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, Filter, FileText, Users, Calendar } from "lucide-react"
import AdminContentActions from "@/components/admin/admin-content-actions"

export default async function AdminContentManagement() {
  const supabase = createServerComponentClient({ cookies })

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("user_profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch all content with author information
  const { data: allContent } = await supabase
    .from("content")
    .select(
      `
      *,
      user_profiles(username, email),
      content_engagement(views, likes)
    `,
    )
    .order("created_at", { ascending: false })

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">内容管理</h1>
            <p className="text-gray-300">管理平台上的所有内容</p>
          </div>
          <Button className="bg-purple-600 hover:bg-purple-700 text-white">
            <FileText className="h-4 w-4 mr-2" />
            导出报告
          </Button>
        </div>

        {/* Filters */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Filter className="h-5 w-5" />
              筛选和搜索
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-white">搜索标题</label>
                <Input
                  placeholder="搜索内容标题..."
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-white">内容类型</label>
                <Select>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="选择类型" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    <SelectItem value="article">文章</SelectItem>
                    <SelectItem value="video">视频</SelectItem>
                    <SelectItem value="audio">音频</SelectItem>
                    <SelectItem value="image">图片</SelectItem>
                    <SelectItem value="document">文档</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-white">发布状态</label>
                <Select>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="选择状态" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    <SelectItem value="published">已发布</SelectItem>
                    <SelectItem value="draft">草稿</SelectItem>
                    <SelectItem value="archived">已归档</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-white">价格类型</label>
                <Select>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder="选择价格" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">全部</SelectItem>
                    <SelectItem value="free">免费</SelectItem>
                    <SelectItem value="paid">付费</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content List */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">内容列表</CardTitle>
            <CardDescription className="text-gray-300">共 {allContent?.length || 0} 个内容项目</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {allContent?.map((content: any) => (
                <div
                  key={content.id}
                  className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-3">
                      <h3 className="text-white font-medium">{content.title}</h3>
                      <Badge
                        variant={content.status === "published" ? "default" : "secondary"}
                        className={
                          content.status === "published"
                            ? "bg-green-500/20 text-green-300"
                            : content.status === "draft"
                              ? "bg-yellow-500/20 text-yellow-300"
                              : "bg-gray-500/20 text-gray-300"
                        }
                      >
                        {content.status === "published" ? "已发布" : content.status === "draft" ? "草稿" : "已归档"}
                      </Badge>
                      <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                        {content.content_type}
                      </Badge>
                      {!content.is_free && (
                        <Badge variant="outline" className="border-yellow-500/30 text-yellow-300">
                          ¥{content.price}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-6 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {content.user_profiles?.username || "未知作者"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        {content.content_engagement?.[0]?.views || 0} 浏览
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(content.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    {content.description && <p className="text-gray-300 text-sm line-clamp-2">{content.description}</p>}
                  </div>

                  <div className="flex items-center gap-2">
                    <AdminContentActions contentId={content.id} currentStatus={content.status} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
