import { redirect } from "next/navigation"
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Users, Mail, Calendar } from "lucide-react"
import AdminUserActions from "@/components/admin/admin-user-actions"

export default async function AdminUserManagement() {
  const supabase = createServerComponentClient({ cookies })

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("user_profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch all users with their content and order statistics
  const { data: allUsers } = await supabase.from("user_profiles").select(`
      *,
      content(count),
      orders(count)
    `)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">用户管理</h1>
            <p className="text-gray-300">管理平台用户账户和权限</p>
          </div>
          <Button className="bg-blue-600 hover:bg-blue-700 text-white">
            <Users className="h-4 w-4 mr-2" />
            导出用户数据
          </Button>
        </div>

        {/* Search */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">搜索用户</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <Input
                placeholder="搜索用户名..."
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
              />
              <Input
                placeholder="搜索邮箱..."
                className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
              />
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">搜索</Button>
            </div>
          </CardContent>
        </Card>

        {/* User List */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">用户列表</CardTitle>
            <CardDescription className="text-gray-300">共 {allUsers?.length || 0} 个用户</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {allUsers?.map((userProfile: any) => (
                <div
                  key={userProfile.id}
                  className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                      <span className="text-white font-bold text-lg">
                        {userProfile.username?.charAt(0).toUpperCase() || "U"}
                      </span>
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-3">
                        <h3 className="text-white font-medium">{userProfile.username || "未设置用户名"}</h3>
                        <Badge
                          variant={userProfile.role === "admin" ? "default" : "secondary"}
                          className={
                            userProfile.role === "admin" ? "bg-red-500/20 text-red-300" : "bg-blue-500/20 text-blue-300"
                          }
                        >
                          {userProfile.role === "admin" ? "管理员" : "用户"}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-6 text-sm text-gray-400">
                        <span className="flex items-center gap-1">
                          <Mail className="h-4 w-4" />
                          {userProfile.email || "未设置邮箱"}
                        </span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(userProfile.created_at).toLocaleDateString()}
                        </span>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-400">
                        <span>内容: {userProfile.content?.length || 0}</span>
                        <span>订单: {userProfile.orders?.length || 0}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <AdminUserActions userId={userProfile.id} currentRole={userProfile.role} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
