import { redirect } from "next/navigation"
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { TrendingUp, Users, FileText, DollarSign, Eye, Calendar, Activity } from "lucide-react"

export default async function AdminAnalytics() {
  const supabase = createServerComponentClient({ cookies })

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("user_profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch analytics data
  const [
    { data: contentStats },
    { data: userGrowth },
    { data: revenueData },
    { data: topCategories },
    { data: engagementStats },
  ] = await Promise.all([
    supabase
      .from("content")
      .select("content_type, is_free, created_at")
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
    supabase
      .from("user_profiles")
      .select("created_at")
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
    supabase
      .from("orders")
      .select("amount, created_at")
      .eq("status", "completed")
      .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()),
    supabase.from("content").select("category").neq("category", "").limit(100),
    supabase.from("content_engagement").select("views, likes, content_id"),
  ])

  // Process data
  const totalRevenue = revenueData?.reduce((sum, order) => sum + order.amount, 0) || 0
  const newUsers = userGrowth?.length || 0
  const newContent = contentStats?.length || 0
  const totalViews = engagementStats?.reduce((sum, stat) => sum + (stat.views || 0), 0) || 0

  // Category analysis
  const categoryCount: { [key: string]: number } = {}
  topCategories?.forEach((content) => {
    if (content.category) {
      categoryCount[content.category] = (categoryCount[content.category] || 0) + 1
    }
  })

  const sortedCategories = Object.entries(categoryCount)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 5)

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-white">分析报告</h1>
          <p className="text-gray-300">平台数据分析和统计报告</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 border-green-500/30 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">月收入</CardTitle>
              <DollarSign className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">¥{totalRevenue.toFixed(2)}</div>
              <p className="text-xs text-green-300">本月总收入</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-600/20 to-cyan-600/20 border-blue-500/30 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">新用户</CardTitle>
              <Users className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{newUsers}</div>
              <p className="text-xs text-blue-300">本月新注册</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 border-purple-500/30 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">新内容</CardTitle>
              <FileText className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{newContent}</div>
              <p className="text-xs text-purple-300">本月发布</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-600/20 to-red-600/20 border-orange-500/30 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">总浏览量</CardTitle>
              <Eye className="h-4 w-4 text-orange-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalViews.toLocaleString()}</div>
              <p className="text-xs text-orange-300">累计浏览</p>
            </CardContent>
          </Card>
        </div>

        {/* Charts and Analysis */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Top Categories */}
          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                热门分类
              </CardTitle>
              <CardDescription className="text-gray-300">内容分类统计</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {sortedCategories.map(([category, count], index) => (
                  <div key={category} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                        #{index + 1}
                      </Badge>
                      <span className="text-white">{category}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-20 h-2 bg-white/10 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                          style={{ width: `${(count / Math.max(...Object.values(categoryCount))) * 100}%` }}
                        />
                      </div>
                      <span className="text-gray-300 text-sm">{count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Content Type Distribution */}
          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="h-5 w-5" />
                内容类型分布
              </CardTitle>
              <CardDescription className="text-gray-300">不同类型内容的数量</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {["article", "video", "audio", "image", "document"].map((type) => {
                  const count = contentStats?.filter((c) => c.content_type === type).length || 0
                  const percentage = contentStats?.length ? (count / contentStats.length) * 100 : 0
                  return (
                    <div key={type} className="flex items-center justify-between">
                      <span className="text-white capitalize">{type}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-20 h-2 bg-white/10 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-blue-500 to-cyan-500"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                        <span className="text-gray-300 text-sm">{count}</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Revenue and Growth Trends */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Calendar className="h-5 w-5" />
              增长趋势
            </CardTitle>
            <CardDescription className="text-gray-300">过去30天的平台增长数据</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-6">
              <div className="text-center space-y-2">
                <div className="text-3xl font-bold text-green-400">¥{totalRevenue.toFixed(0)}</div>
                <p className="text-gray-300">月收入</p>
                <Badge className="bg-green-500/20 text-green-300">+12.5%</Badge>
              </div>
              <div className="text-center space-y-2">
                <div className="text-3xl font-bold text-blue-400">{newUsers}</div>
                <p className="text-gray-300">新用户</p>
                <Badge className="bg-blue-500/20 text-blue-300">+8.3%</Badge>
              </div>
              <div className="text-center space-y-2">
                <div className="text-3xl font-bold text-purple-400">{newContent}</div>
                <p className="text-gray-300">新内容</p>
                <Badge className="bg-purple-500/20 text-purple-300">+15.7%</Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
