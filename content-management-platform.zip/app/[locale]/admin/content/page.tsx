"use client"

import { redirect } from "next/navigation"
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { useTranslations } from "next-intl"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Eye, Filter, FileText, Users, Calendar } from "lucide-react"
import AdminContentActions from "@/components/admin/admin-content-actions"
import LanguageSwitcher from "@/components/language-switcher"

interface AdminContentManagementProps {
  params: { locale: string }
}

export default async function AdminContentManagement({ params: { locale } }: AdminContentManagementProps) {
  const supabase = createServerComponentClient({ cookies })

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin
  const { data: profile } = await supabase.from("user_profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch all content with author information
  const { data: allContent } = await supabase
    .from("content")
    .select(
      `
      *,
      user_profiles(username, email),
      content_engagement(views, likes)
    `,
    )
    .order("created_at", { ascending: false })

  return <AdminContentManagementContent allContent={allContent} />
}

function AdminContentManagementContent({ allContent }: { allContent: any[] | null }) {
  const t = useTranslations("admin.content")
  const tStatus = useTranslations("content.status")
  const tCategories = useTranslations("content.categories")
  const tCommon = useTranslations("common")

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">{t("title")}</h1>
            <p className="text-gray-300">{t("manageDesc")}</p>
          </div>
          <div className="flex items-center space-x-4">
            <LanguageSwitcher />
            <Button className="bg-purple-600 hover:bg-purple-700 text-white">
              <FileText className="h-4 w-4 mr-2" />
              {t("exportReport")}
            </Button>
          </div>
        </div>

        {/* Filters */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Filter className="h-5 w-5" />
              {t("filterAndSearch")}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-4 gap-4">
              <div className="space-y-2">
                <label className="text-sm text-white">{t("searchTitle")}</label>
                <Input
                  placeholder={t("searchTitlePlaceholder")}
                  className="bg-white/5 border-white/10 text-white placeholder:text-gray-500"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm text-white">{t("contentType")}</label>
                <Select>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder={t("selectType")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{tCommon("all")}</SelectItem>
                    <SelectItem value="article">{t("contentTypes.article")}</SelectItem>
                    <SelectItem value="video">{t("contentTypes.video")}</SelectItem>
                    <SelectItem value="audio">{t("contentTypes.audio")}</SelectItem>
                    <SelectItem value="image">{t("contentTypes.image")}</SelectItem>
                    <SelectItem value="document">{t("contentTypes.document")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-white">{t("publishStatus")}</label>
                <Select>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder={t("selectStatus")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{tCommon("all")}</SelectItem>
                    <SelectItem value="published">{tStatus("published")}</SelectItem>
                    <SelectItem value="draft">{tStatus("draft")}</SelectItem>
                    <SelectItem value="archived">{tStatus("archived")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm text-white">{t("priceType")}</label>
                <Select>
                  <SelectTrigger className="bg-white/5 border-white/10 text-white">
                    <SelectValue placeholder={t("selectPrice")} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{tCommon("all")}</SelectItem>
                    <SelectItem value="free">{t("free")}</SelectItem>
                    <SelectItem value="paid">{t("paid")}</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Content List */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white">{t("contentList")}</CardTitle>
            <CardDescription className="text-gray-300">
              {t("totalItems", { count: allContent?.length || 0 })}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {allContent?.map((content: any) => (
                <div
                  key={content.id}
                  className="flex items-center justify-between p-4 bg-white/5 rounded-lg border border-white/10"
                >
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center gap-3">
                      <h3 className="text-white font-medium">{content.title}</h3>
                      <Badge
                        variant={content.status === "published" ? "default" : "secondary"}
                        className={
                          content.status === "published"
                            ? "bg-green-500/20 text-green-300"
                            : content.status === "draft"
                              ? "bg-yellow-500/20 text-yellow-300"
                              : "bg-gray-500/20 text-gray-300"
                        }
                      >
                        {tStatus(content.status)}
                      </Badge>
                      <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                        {content.content_type}
                      </Badge>
                      {!content.is_free && (
                        <Badge variant="outline" className="border-yellow-500/30 text-yellow-300">
                          ¥{content.price}
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-6 text-sm text-gray-400">
                      <span className="flex items-center gap-1">
                        <Users className="h-4 w-4" />
                        {content.user_profiles?.username || t("unknownAuthor")}
                      </span>
                      <span className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        {content.content_engagement?.[0]?.views || 0} {t("views")}
                      </span>
                      <span className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        {new Date(content.created_at).toLocaleDateString()}
                      </span>
                    </div>
                    {content.description && <p className="text-gray-300 text-sm line-clamp-2">{content.description}</p>}
                  </div>

                  <div className="flex items-center gap-2">
                    <AdminContentActions contentId={content.id} currentStatus={content.status} />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
