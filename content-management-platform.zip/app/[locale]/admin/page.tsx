"use client"

import { redirect } from "next/navigation"
import { createServerComponentClient } from "@supabase/auth-helpers-nextjs"
import { cookies } from "next/headers"
import { useTranslations } from "next-intl"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Users, FileText, CreditCard, TrendingUp, Eye, DollarSign, Activity } from "lucide-react"
import LanguageSwitcher from "@/components/language-switcher"

interface AdminDashboardProps {
  params: { locale: string }
}

export default async function AdminDashboard({ params: { locale } }: AdminDashboardProps) {
  const supabase = createServerComponentClient({ cookies })

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Check if user is admin (you can implement your own admin check logic)
  const { data: profile } = await supabase.from("user_profiles").select("role").eq("id", user.id).single()

  if (profile?.role !== "admin") {
    redirect("/dashboard")
  }

  // Fetch dashboard statistics
  const [
    { count: totalUsers },
    { count: totalContent },
    { count: totalOrders },
    { data: recentContent },
    { data: recentOrders },
    { data: topContent },
  ] = await Promise.all([
    supabase.from("user_profiles").select("*", { count: "exact", head: true }),
    supabase.from("content").select("*", { count: "exact", head: true }),
    supabase.from("orders").select("*", { count: "exact", head: true }),
    supabase
      .from("content")
      .select("id, title, author_id, created_at, status, user_profiles(username)")
      .order("created_at", { ascending: false })
      .limit(5),
    supabase
      .from("orders")
      .select("id, amount, status, created_at, user_profiles(username)")
      .order("created_at", { ascending: false })
      .limit(5),
    supabase.from("content").select("id, title, views, likes").order("views", { ascending: false }).limit(5),
  ])

  // Calculate revenue
  const { data: revenue } = await supabase
    .from("orders")
    .select("amount")
    .eq("status", "completed")
    .gte("created_at", new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString())

  const monthlyRevenue = revenue?.reduce((sum, order) => sum + order.amount, 0) || 0

  return (
    <AdminDashboardContent
      totalUsers={totalUsers}
      totalContent={totalContent}
      totalOrders={totalOrders}
      monthlyRevenue={monthlyRevenue}
      recentContent={recentContent}
      recentOrders={recentOrders}
      topContent={topContent}
    />
  )
}

function AdminDashboardContent({
  totalUsers,
  totalContent,
  totalOrders,
  monthlyRevenue,
  recentContent,
  recentOrders,
  topContent,
}: any) {
  const t = useTranslations("admin")
  const tOverview = useTranslations("admin.overview")
  const tContent = useTranslations("admin.content")
  const tUsers = useTranslations("admin.users")
  const tAnalytics = useTranslations("admin.analytics")
  const tStatus = useTranslations("content.status")

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 p-6">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-bold text-white">{t("title")}</h1>
            <p className="text-xl text-gray-300">{t("subtitle")}</p>
          </div>
          <LanguageSwitcher />
        </div>

        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">{tOverview("totalUsers")}</CardTitle>
              <Users className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalUsers || 0}</div>
              <p className="text-xs text-gray-400">{tOverview("totalUsersDesc")}</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">{tOverview("totalContent")}</CardTitle>
              <FileText className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalContent || 0}</div>
              <p className="text-xs text-gray-400">{tOverview("totalContentDesc")}</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">{tOverview("totalOrders")}</CardTitle>
              <CreditCard className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{totalOrders || 0}</div>
              <p className="text-xs text-gray-400">{tOverview("totalOrdersDesc")}</p>
            </CardContent>
          </Card>

          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-white">{tOverview("totalRevenue")}</CardTitle>
              <DollarSign className="h-4 w-4 text-yellow-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">¥{monthlyRevenue.toFixed(2)}</div>
              <p className="text-xs text-gray-400">{tOverview("monthlyGrowth")}</p>
            </CardContent>
          </Card>
        </div>

        {/* Content and Orders Overview */}
        <div className="grid lg:grid-cols-2 gap-8">
          {/* Recent Content */}
          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <FileText className="h-5 w-5" />
                {tContent("recentContent")}
              </CardTitle>
              <CardDescription className="text-gray-300">{tContent("recentContentDesc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentContent?.map((content: any) => (
                  <div key={content.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <div className="space-y-1">
                      <p className="text-white font-medium">{content.title}</p>
                      <p className="text-sm text-gray-400">
                        {tContent("author")}: {content.user_profiles?.username || tContent("unknownAuthor")}
                      </p>
                    </div>
                    <div className="text-right space-y-1">
                      <Badge
                        variant={content.status === "published" ? "default" : "secondary"}
                        className={
                          content.status === "published"
                            ? "bg-green-500/20 text-green-300"
                            : "bg-yellow-500/20 text-yellow-300"
                        }
                      >
                        {tStatus(content.status)}
                      </Badge>
                      <p className="text-xs text-gray-400">{new Date(content.created_at).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Orders */}
          <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <CreditCard className="h-5 w-5" />
                {tContent("recentOrders")}
              </CardTitle>
              <CardDescription className="text-gray-300">{tContent("recentOrdersDesc")}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentOrders?.map((order: any) => (
                  <div key={order.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                    <div className="space-y-1">
                      <p className="text-white font-medium">
                        {tContent("orderNumber")} #{order.id.slice(0, 8)}
                      </p>
                      <p className="text-sm text-gray-400">
                        {tUsers("user")}: {order.user_profiles?.username || tContent("unknownUser")}
                      </p>
                    </div>
                    <div className="text-right space-y-1">
                      <p className="text-white font-medium">¥{order.amount}</p>
                      <Badge
                        variant={order.status === "completed" ? "default" : "secondary"}
                        className={
                          order.status === "completed"
                            ? "bg-green-500/20 text-green-300"
                            : "bg-yellow-500/20 text-yellow-300"
                        }
                      >
                        {order.status === "completed" ? tContent("completed") : tContent("processing")}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Top Content */}
        <Card className="bg-white/10 border-white/20 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              {tAnalytics("topContent")}
            </CardTitle>
            <CardDescription className="text-gray-300">{tContent("topContentDesc")}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {topContent?.map((content: any, index: number) => (
                <div key={content.id} className="p-4 bg-white/5 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                      #{index + 1}
                    </Badge>
                    <div className="flex items-center gap-2 text-gray-400">
                      <Eye className="h-4 w-4" />
                      <span className="text-sm">{content.views || 0}</span>
                    </div>
                  </div>
                  <h4 className="text-white font-medium">{content.title}</h4>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <span>👍 {content.likes || 0}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="bg-gradient-to-br from-purple-600/20 to-pink-600/20 border-purple-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <FileText className="h-5 w-5" />
                {tContent("title")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">{tContent("manageDesc")}</p>
              <a
                href="/admin/content"
                className="inline-flex items-center px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors"
              >
                {tContent("manageContent")}
              </a>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-600/20 to-cyan-600/20 border-blue-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Users className="h-5 w-5" />
                {tUsers("title")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">{tUsers("manageDesc")}</p>
              <a
                href="/admin/users"
                className="inline-flex items-center px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
              >
                {tUsers("manageUsers")}
              </a>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-600/20 to-emerald-600/20 border-green-500/30 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Activity className="h-5 w-5" />
                {tAnalytics("title")}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-300 mb-4">{tAnalytics("viewDesc")}</p>
              <a
                href="/admin/analytics"
                className="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors"
              >
                {tAnalytics("viewAnalytics")}
              </a>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
