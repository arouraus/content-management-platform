import { createClient } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import ContentForm from "@/components/content/content-form"

export default async function CreateContentPage() {
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 py-8">
      <div className="container mx-auto px-4">
        <ContentForm userId={user.id} />
      </div>
    </div>
  )
}
