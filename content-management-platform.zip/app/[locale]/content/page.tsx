"use client"

import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { useTranslations } from "next-intl"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Plus, Eye, Heart, Calendar, User } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { zhCN, enUS } from "date-fns/locale"
import LanguageSwitcher from "@/components/language-switcher"

interface ContentPageProps {
  params: { locale: string }
}

export default async function ContentPage({ params: { locale } }: ContentPageProps) {
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold mb-4 text-white">Connect Supabase to get started</h1>
      </div>
    )
  }

  const supabase = createClient()

  // Get published content with author information
  const { data: content, error } = await supabase
    .from("content")
    .select(`
      *,
      user_profiles!content_author_id_fkey (
        full_name,
        avatar_url
      )
    `)
    .eq("status", "published")
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching content:", error)
  }

  return <ContentPageContent content={content} locale={locale} />
}

function ContentPageContent({ content, locale }: { content: any[] | null; locale: string }) {
  const t = useTranslations("content")
  const tNav = useTranslations("navigation")
  const tCommon = useTranslations("common")
  const tCategories = useTranslations("content.categories")

  const dateLocale = locale === "zh" ? zhCN : enUS

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">ContentHub</span>
          </Link>
          <div className="flex items-center space-x-4">
            <LanguageSwitcher />
            <Link href="/dashboard">
              <Button variant="ghost" className="text-white hover:text-purple-300">
                {tNav("dashboard")}
              </Button>
            </Link>
            <Link href="/content/create">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Plus className="h-4 w-4 mr-2" />
                {t("createNew")}
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">{t("title")}</h1>
          <p className="text-gray-300">{t("subtitle")}</p>
        </div>

        {/* Content Grid */}
        {content && content.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {content.map((item) => (
              <Card
                key={item.id}
                className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 group"
              >
                <CardHeader>
                  {item.thumbnail_url && (
                    <div className="w-full h-48 bg-gray-800 rounded-lg mb-4 overflow-hidden">
                      <img
                        src={item.thumbnail_url || "/placeholder.svg"}
                        alt={item.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary" className="bg-purple-600/20 text-purple-300 border-purple-600/30">
                      {item.content_type}
                    </Badge>
                    {!item.is_free && (
                      <Badge variant="outline" className="border-yellow-500/50 text-yellow-400">
                        {t("paidContent")}
                      </Badge>
                    )}
                  </div>
                  <CardTitle className="text-white group-hover:text-purple-300 transition-colors">
                    <Link href={`/content/${item.id}`}>{item.title}</Link>
                  </CardTitle>
                  {item.description && (
                    <CardDescription className="text-gray-300 line-clamp-2">{item.description}</CardDescription>
                  )}
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-gray-400">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-1">
                        <Eye className="h-4 w-4" />
                        <span>{item.view_count}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Heart className="h-4 w-4" />
                        <span>{item.like_count}</span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Calendar className="h-4 w-4" />
                      <span>
                        {formatDistanceToNow(new Date(item.created_at), {
                          addSuffix: true,
                          locale: dateLocale,
                        })}
                      </span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2 mt-3 pt-3 border-t border-white/10">
                    <User className="h-4 w-4 text-gray-400" />
                    <span className="text-sm text-gray-300">{item.user_profiles?.full_name || t("anonymousUser")}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">{t("noContent")}</h3>
            <p className="text-gray-400 mb-6">{t("noContentDescription")}</p>
            <Link href="/content/create">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                <Plus className="h-4 w-4 mr-2" />
                {t("createFirst")}
              </Button>
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
