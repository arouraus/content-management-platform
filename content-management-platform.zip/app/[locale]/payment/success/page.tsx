"use client"

import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { redirect, notFound } from "next/navigation"
import { useTranslations } from "next-intl"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Download, Eye, ArrowRight } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { zhCN, enUS } from "date-fns/locale"

interface PaymentSuccessPageProps {
  searchParams: {
    order?: string
  }
  params: { locale: string }
}

export default async function PaymentSuccessPage({ searchParams, params: { locale } }: PaymentSuccessPageProps) {
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold mb-4 text-white">Connect Supabase to get started</h1>
      </div>
    )
  }

  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  if (!searchParams.order) {
    notFound()
  }

  // Get order details
  const { data: order, error } = await supabase
    .from("orders")
    .select(`
      *,
      content (
        *,
        user_profiles!content_author_id_fkey (
          full_name
        )
      ),
      payments (*)
    `)
    .eq("order_number", searchParams.order)
    .eq("user_id", user.id)
    .single()

  if (error || !order) {
    notFound()
  }

  const payment = order.payments?.[0]

  return <PaymentSuccessContent order={order} payment={payment} locale={locale} />
}

function PaymentSuccessContent({ order, payment, locale }: { order: any; payment: any; locale: string }) {
  const t = useTranslations("payment.success")
  const tStatus = useTranslations("payment.status")
  const tCommon = useTranslations("common")

  const dateLocale = locale === "zh" ? zhCN : enUS

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case "credit_card":
        return t("creditCard")
      case "alipay":
        return t("alipay")
      case "wechat_pay":
        return t("wechatPay")
      default:
        return method
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <Link href="/" className="flex items-center space-x-2">
            <span className="text-2xl font-bold text-white">ContentHub</span>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Success Message */}
          <div className="text-center mb-8">
            <CheckCircle className="h-20 w-20 text-green-400 mx-auto mb-4" />
            <h1 className="text-4xl font-bold text-white mb-2">{t("title")}</h1>
            <p className="text-gray-300 text-lg">{t("message")}</p>
          </div>

          {/* Order Details */}
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm mb-6">
            <CardHeader>
              <CardTitle className="text-white flex items-center space-x-2">
                <span>{t("orderDetails")}</span>
                <Badge variant="outline" className="border-green-500/50 text-green-400">
                  {tStatus("completed")}
                </Badge>
              </CardTitle>
              <CardDescription className="text-gray-300">
                {t("orderNumber")}: {order.order_number}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start space-x-4">
                {order.content.thumbnail_url && (
                  <img
                    src={order.content.thumbnail_url || "/placeholder.svg"}
                    alt={order.content.title}
                    className="w-20 h-20 object-cover rounded-lg"
                  />
                )}
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-white">{order.content.title}</h3>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge variant="secondary" className="bg-purple-600/20 text-purple-300">
                      {order.content.content_type}
                    </Badge>
                    {payment?.metadata?.access_level && (
                      <Badge variant="outline" className="border-yellow-500/50 text-yellow-400">
                        {payment.metadata.access_level.toUpperCase()}
                      </Badge>
                    )}
                  </div>
                  <p className="text-gray-400 text-sm mt-1">
                    {tCommon("author")}: {order.content.user_profiles?.full_name || t("anonymousUser")}
                  </p>
                </div>
                <div className="text-right">
                  <div className="text-2xl font-bold text-white">¥{order.amount}</div>
                  <div className="text-sm text-gray-400">{order.currency || "CNY"}</div>
                </div>
              </div>

              <div className="border-t border-white/10 pt-4 grid grid-cols-2 gap-4 text-sm">
                <div>
                  <span className="text-gray-400">{t("paymentMethod")}:</span>
                  <div className="text-white font-medium">{getPaymentMethodLabel(order.payment_method)}</div>
                </div>
                <div>
                  <span className="text-gray-400">{t("paymentTime")}:</span>
                  <div className="text-white font-medium">
                    {formatDistanceToNow(new Date(order.created_at), {
                      addSuffix: true,
                      locale: dateLocale,
                    })}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Payment Details */}
          {payment && (
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm mb-6">
              <CardHeader>
                <CardTitle className="text-white">{t("paymentInfo")}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-400">{t("paymentProvider")}:</span>
                  <span className="text-white font-medium">{payment.payment_provider}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">{t("transactionId")}:</span>
                  <span className="text-white font-mono text-sm">{payment.provider_payment_id}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">{t("paymentStatus")}:</span>
                  <Badge variant="outline" className="border-green-500/50 text-green-400">
                    {tStatus(payment.status)}
                  </Badge>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href={`/content/${order.content.id}`} className="flex-1">
              <Button className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                <Eye className="h-4 w-4 mr-2" />
                {t("accessContent")}
              </Button>
            </Link>
            <Link href="/library" className="flex-1">
              <Button variant="outline" className="w-full border-white/20 text-white hover:bg-white/10 bg-transparent">
                <ArrowRight className="h-4 w-4 mr-2" />
                {t("viewLibrary")}
              </Button>
            </Link>
          </div>

          {/* Receipt Download */}
          <div className="text-center mt-6">
            <Button variant="ghost" className="text-gray-400 hover:text-white">
              <Download className="h-4 w-4 mr-2" />
              {t("downloadReceipt")}
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}
