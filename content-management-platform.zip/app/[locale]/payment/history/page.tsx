"use client"

import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { useTranslations } from "next-intl"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Receipt, Eye } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { zhCN, enUS } from "date-fns/locale"
import LanguageSwitcher from "@/components/language-switcher"

interface PaymentHistoryPageProps {
  params: { locale: string }
}

export default async function PaymentHistoryPage({ params: { locale } }: PaymentHistoryPageProps) {
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold mb-4 text-white">Connect Supabase to get started</h1>
      </div>
    )
  }

  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user's payment history
  const { data: orders, error } = await supabase
    .from("orders")
    .select(`
      *,
      content (
        title,
        content_type,
        thumbnail_url
      ),
      payments (*)
    `)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching payment history:", error)
  }

  return <PaymentHistoryContent orders={orders || []} locale={locale} />
}

function PaymentHistoryContent({ orders, locale }: { orders: any[]; locale: string }) {
  const t = useTranslations("payment.history")
  const tStatus = useTranslations("payment.status")
  const tNav = useTranslations("navigation")
  const tCommon = useTranslations("common")

  const dateLocale = locale === "zh" ? zhCN : enUS

  const getPaymentMethodLabel = (method: string) => {
    switch (method) {
      case "credit_card":
        return t("creditCard")
      case "alipay":
        return t("alipay")
      case "wechat_pay":
        return t("wechatPay")
      default:
        return method
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "border-green-500/50 text-green-400"
      case "pending":
        return "border-yellow-500/50 text-yellow-400"
      case "failed":
        return "border-red-500/50 text-red-400"
      case "refunded":
        return "border-gray-500/50 text-gray-400"
      default:
        return "border-gray-500/50 text-gray-400"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">ContentHub</span>
          </Link>
          <div className="flex items-center space-x-4">
            <LanguageSwitcher />
            <Link href="/dashboard">
              <Button variant="ghost" className="text-white hover:text-purple-300">
                {tNav("dashboard")}
              </Button>
            </Link>
            <Link href="/library">
              <Button variant="ghost" className="text-white hover:text-purple-300">
                {tNav("library")}
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">{t("title")}</h1>
          <p className="text-gray-300">{t("subtitle")}</p>
        </div>

        {orders.length > 0 ? (
          <div className="space-y-6">
            {orders.map((order) => {
              const payment = order.payments?.[0]
              return (
                <Card key={order.id} className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div>
                        <CardTitle className="text-white flex items-center space-x-2">
                          <span>
                            {t("orderNumber")} {order.order_number}
                          </span>
                          <Badge variant="outline" className={getStatusColor(order.status)}>
                            {tStatus(order.status)}
                          </Badge>
                        </CardTitle>
                        <p className="text-gray-400 text-sm mt-1">
                          {formatDistanceToNow(new Date(order.created_at), {
                            addSuffix: true,
                            locale: dateLocale,
                          })}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-white">¥{order.amount}</div>
                        <div className="text-sm text-gray-400">{order.currency || "CNY"}</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-start space-x-4">
                      {order.content.thumbnail_url && (
                        <img
                          src={order.content.thumbnail_url || "/placeholder.svg"}
                          alt={order.content.title}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                      )}
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-white">{order.content.title}</h3>
                        <Badge variant="secondary" className="bg-purple-600/20 text-purple-300 mt-1">
                          {order.content.content_type}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Link href={`/content/${order.content_id}`}>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-white/20 text-white hover:bg-white/10 bg-transparent"
                          >
                            <Eye className="h-4 w-4 mr-1" />
                            {t("viewContent")}
                          </Button>
                        </Link>
                        <Button size="sm" variant="ghost" className="text-gray-400 hover:text-white">
                          <Receipt className="h-4 w-4 mr-1" />
                          {t("viewReceipt")}
                        </Button>
                      </div>
                    </div>

                    <div className="border-t border-white/10 mt-4 pt-4 grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">{t("paymentMethod")}:</span>
                        <div className="text-white font-medium">{getPaymentMethodLabel(order.payment_method)}</div>
                      </div>
                      {payment && (
                        <div>
                          <span className="text-gray-400">{t("transactionId")}:</span>
                          <div className="text-white font-mono text-xs">{payment.provider_payment_id}</div>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <Receipt className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">{t("noPayments")}</h3>
            <p className="text-gray-400 mb-6">{t("noPaymentsDescription")}</p>
            <Link href="/content">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">{t("browseContent")}</Button>
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
