import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, Eye, Heart } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { zhCN } from "date-fns/locale"

export default async function LibraryPage() {
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold mb-4 text-white">Connect Supabase to get started</h1>
      </div>
    )
  }

  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user's purchased content
  const { data: paidCards, error } = await supabase
    .from("paid_cards")
    .select(`
      *,
      content (
        *,
        user_profiles!content_author_id_fkey (
          full_name,
          avatar_url
        )
      )
    `)
    .eq("user_id", user.id)
    .eq("is_active", true)
    .order("purchase_date", { ascending: false })

  if (error) {
    console.error("Error fetching library:", error)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">ContentHub</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/dashboard">
              <Button variant="ghost" className="text-white hover:text-purple-300">
                控制台
              </Button>
            </Link>
            <Link href="/content">
              <Button variant="ghost" className="text-white hover:text-purple-300">
                浏览内容
              </Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">我的内容库</h1>
          <p className="text-gray-300">您已购买的付费内容</p>
        </div>

        {paidCards && paidCards.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {paidCards.map((card) => {
              const content = card.content
              const isExpired = card.expiry_date && new Date(card.expiry_date) < new Date()

              return (
                <Card
                  key={card.id}
                  className={`bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-all duration-300 group ${
                    isExpired ? "opacity-60" : ""
                  }`}
                >
                  <CardHeader>
                    {content.thumbnail_url && (
                      <div className="w-full h-48 bg-gray-800 rounded-lg mb-4 overflow-hidden">
                        <img
                          src={content.thumbnail_url || "/placeholder.svg"}
                          alt={content.title}
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        />
                      </div>
                    )}

                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="secondary" className="bg-purple-600/20 text-purple-300 border-purple-600/30">
                        {content.content_type}
                      </Badge>
                      <Badge
                        variant="outline"
                        className={`${
                          isExpired
                            ? "border-red-500/50 text-red-400"
                            : card.access_level === "vip"
                              ? "border-yellow-500/50 text-yellow-400"
                              : "border-green-500/50 text-green-400"
                        }`}
                      >
                        {isExpired ? "已过期" : card.access_level.toUpperCase()}
                      </Badge>
                    </div>

                    <CardTitle className="text-white group-hover:text-purple-300 transition-colors">
                      <Link href={`/content/${content.id}`}>{content.title}</Link>
                    </CardTitle>

                    {content.description && (
                      <CardDescription className="text-gray-300 line-clamp-2">{content.description}</CardDescription>
                    )}
                  </CardHeader>

                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <Eye className="h-4 w-4" />
                            <span>{content.view_count}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Heart className="h-4 w-4" />
                            <span>{content.like_count}</span>
                          </div>
                        </div>
                      </div>

                      <div className="border-t border-white/10 pt-3">
                        <div className="flex items-center justify-between text-sm text-gray-400 mb-2">
                          <span>购买时间:</span>
                          <span>
                            {formatDistanceToNow(new Date(card.purchase_date), {
                              addSuffix: true,
                              locale: zhCN,
                            })}
                          </span>
                        </div>

                        {card.expiry_date && (
                          <div className="flex items-center justify-between text-sm text-gray-400">
                            <span>到期时间:</span>
                            <span className={isExpired ? "text-red-400" : "text-yellow-400"}>
                              {formatDistanceToNow(new Date(card.expiry_date), {
                                addSuffix: true,
                                locale: zhCN,
                              })}
                            </span>
                          </div>
                        )}
                      </div>

                      <Link href={`/content/${content.id}`}>
                        <Button
                          className={`w-full ${
                            isExpired ? "bg-gray-600 hover:bg-gray-700" : "bg-purple-600 hover:bg-purple-700"
                          } text-white`}
                          disabled={isExpired}
                        >
                          {isExpired ? "内容已过期" : "查看内容"}
                        </Button>
                      </Link>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <BookOpen className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">暂无购买记录</h3>
            <p className="text-gray-400 mb-6">您还没有购买任何付费内容</p>
            <Link href="/content">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">浏览付费内容</Button>
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
