import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, ArrowLeft, Receipt, Eye } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { zhCN } from "date-fns/locale"

export default async function PaymentHistoryPage() {
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold mb-4 text-white">Connect Supabase to get started</h1>
      </div>
    )
  }

  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user's payment history
  const { data: orders, error } = await supabase
    .from("orders")
    .select(`
      *,
      content (
        id,
        title,
        content_type,
        thumbnail_url,
        user_profiles!content_author_id_fkey (
          full_name
        )
      ),
      payments (*)
    `)
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching payment history:", error)
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "border-green-500/50 text-green-400"
      case "pending":
        return "border-yellow-500/50 text-yellow-400"
      case "failed":
        return "border-red-500/50 text-red-400"
      case "refunded":
        return "border-gray-500/50 text-gray-400"
      default:
        return "border-gray-500/50 text-gray-400"
    }
  }

  const getStatusText = (status: string) => {
    switch (status) {
      case "completed":
        return "已完成"
      case "pending":
        return "处理中"
      case "failed":
        return "失败"
      case "refunded":
        return "已退款"
      default:
        return status
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">ContentHub</span>
          </Link>
          <Link href="/dashboard">
            <Button variant="ghost" className="text-white hover:text-purple-300">
              <ArrowLeft className="h-4 w-4 mr-2" />
              返回控制台
            </Button>
          </Link>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">支付历史</h1>
          <p className="text-gray-300">查看您的所有购买记录和支付详情</p>
        </div>

        {orders && orders.length > 0 ? (
          <div className="space-y-6">
            {orders.map((order) => {
              const payment = order.payments?.[0]

              return (
                <Card key={order.id} className="bg-white/5 border-white/10 backdrop-blur-sm">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-white flex items-center space-x-2">
                          <span>订单 #{order.order_number}</span>
                          <Badge variant="outline" className={getStatusColor(order.status)}>
                            {getStatusText(order.status)}
                          </Badge>
                        </CardTitle>
                        <CardDescription className="text-gray-300">
                          {formatDistanceToNow(new Date(order.created_at), {
                            addSuffix: true,
                            locale: zhCN,
                          })}
                        </CardDescription>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-white">¥{order.amount}</div>
                        <div className="text-sm text-gray-400">{order.currency || "CNY"}</div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent>
                    <div className="flex items-start space-x-4 mb-4">
                      {order.content.thumbnail_url && (
                        <img
                          src={order.content.thumbnail_url || "/placeholder.svg"}
                          alt={order.content.title}
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                      )}
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-white">{order.content.title}</h3>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="secondary" className="bg-purple-600/20 text-purple-300">
                            {order.content.content_type}
                          </Badge>
                          {payment?.metadata?.access_level && (
                            <Badge variant="outline" className="border-yellow-500/50 text-yellow-400">
                              {payment.metadata.access_level.toUpperCase()}
                            </Badge>
                          )}
                        </div>
                        <p className="text-gray-400 text-sm mt-1">
                          作者: {order.content.user_profiles?.full_name || "匿名用户"}
                        </p>
                      </div>
                    </div>

                    <div className="border-t border-white/10 pt-4">
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                        <div>
                          <span className="text-gray-400">支付方式:</span>
                          <div className="text-white font-medium">
                            {order.payment_method === "credit_card" && "信用卡"}
                            {order.payment_method === "alipay" && "支付宝"}
                            {order.payment_method === "wechat_pay" && "微信支付"}
                          </div>
                        </div>
                        {payment && (
                          <>
                            <div>
                              <span className="text-gray-400">支付提供商:</span>
                              <div className="text-white font-medium">{payment.payment_provider}</div>
                            </div>
                            <div>
                              <span className="text-gray-400">交易ID:</span>
                              <div className="text-white font-mono text-xs">{payment.provider_payment_id}</div>
                            </div>
                            <div>
                              <span className="text-gray-400">支付状态:</span>
                              <Badge variant="outline" className={getStatusColor(payment.status)}>
                                {getStatusText(payment.status)}
                              </Badge>
                            </div>
                          </>
                        )}
                      </div>

                      <div className="flex items-center space-x-4">
                        {order.status === "completed" && (
                          <Link href={`/content/${order.content.id}`}>
                            <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white">
                              <Eye className="h-4 w-4 mr-2" />
                              查看内容
                            </Button>
                          </Link>
                        )}
                        <Link href={`/payment/success?order=${order.order_number}`}>
                          <Button
                            size="sm"
                            variant="outline"
                            className="border-white/20 text-white hover:bg-white/10 bg-transparent"
                          >
                            <Receipt className="h-4 w-4 mr-2" />
                            查看收据
                          </Button>
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )
            })}
          </div>
        ) : (
          <div className="text-center py-12">
            <Receipt className="h-16 w-16 text-gray-600 mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-white mb-2">暂无支付记录</h3>
            <p className="text-gray-400 mb-6">您还没有任何购买记录</p>
            <Link href="/content">
              <Button className="bg-purple-600 hover:bg-purple-700 text-white">浏览付费内容</Button>
            </Link>
          </div>
        )}
      </main>
    </div>
  )
}
