import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { notFound } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { BookOpen, ArrowLeft, Eye, Heart, Calendar, User, Edit } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { zhCN } from "date-fns/locale"
import PurchaseButton from "@/components/content/purchase-button"

interface ContentDetailPageProps {
  params: {
    id: string
  }
}

export default async function ContentDetailPage({ params }: ContentDetailPageProps) {
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold mb-4 text-white">Connect Supabase to get started</h1>
      </div>
    )
  }

  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // Get content with author information
  const { data: content, error } = await supabase
    .from("content")
    .select(`
      *,
      user_profiles!content_author_id_fkey (
        full_name,
        avatar_url
      )
    `)
    .eq("id", params.id)
    .single()

  if (error || !content) {
    notFound()
  }

  // Check if user has purchased this content
  let hasPurchased = false
  if (user && !content.is_free) {
    const { data: paidCard } = await supabase
      .from("paid_cards")
      .select("*")
      .eq("content_id", content.id)
      .eq("user_id", user.id)
      .eq("is_active", true)
      .single()

    hasPurchased = !!paidCard && (!paidCard.expiry_date || new Date(paidCard.expiry_date) > new Date())
  }

  // Check if user can access this content
  const canAccess = content.is_free || content.author_id === user?.id || hasPurchased

  // Increment view count (only for published content and if user can access)
  if (content.status === "published" && canAccess) {
    await supabase.rpc("increment_content_views", { content_uuid: content.id })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">ContentHub</span>
          </Link>
          <div className="flex items-center space-x-4">
            <Link href="/content">
              <Button variant="ghost" className="text-white hover:text-purple-300">
                <ArrowLeft className="h-4 w-4 mr-2" />
                返回列表
              </Button>
            </Link>
            {user?.id === content.author_id && (
              <Link href={`/content/${content.id}/edit`}>
                <Button className="bg-purple-600 hover:bg-purple-700 text-white">
                  <Edit className="h-4 w-4 mr-2" />
                  编辑
                </Button>
              </Link>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              {content.thumbnail_url && (
                <div className="w-full h-64 bg-gray-800 rounded-lg mb-6 overflow-hidden">
                  <img
                    src={content.thumbnail_url || "/placeholder.svg"}
                    alt={content.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Badge variant="secondary" className="bg-purple-600/20 text-purple-300 border-purple-600/30">
                    {content.content_type}
                  </Badge>
                  {!content.is_free && (
                    <Badge variant="outline" className="border-yellow-500/50 text-yellow-400">
                      付费内容 ¥{content.price}
                    </Badge>
                  )}
                  <Badge variant="outline" className="border-green-500/50 text-green-400">
                    {content.status}
                  </Badge>
                </div>
              </div>

              <CardTitle className="text-3xl font-bold text-white mb-4">{content.title}</CardTitle>

              {content.description && (
                <CardDescription className="text-lg text-gray-300 mb-6">{content.description}</CardDescription>
              )}

              <div className="flex items-center justify-between text-sm text-gray-400 border-b border-white/10 pb-4">
                <div className="flex items-center space-x-6">
                  <div className="flex items-center space-x-1">
                    <Eye className="h-4 w-4" />
                    <span>{content.view_count} 浏览</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Heart className="h-4 w-4" />
                    <span>{content.like_count} 点赞</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Calendar className="h-4 w-4" />
                    <span>
                      {formatDistanceToNow(new Date(content.created_at), {
                        addSuffix: true,
                        locale: zhCN,
                      })}
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <User className="h-4 w-4" />
                  <span>{content.user_profiles?.full_name || "匿名用户"}</span>
                </div>
              </div>
            </CardHeader>

            <CardContent>
              {canAccess ? (
                <div className="prose prose-invert max-w-none">
                  {content.content_url && (
                    <div className="mb-6">
                      {content.content_type === "video" && (
                        <video controls className="w-full rounded-lg">
                          <source src={content.content_url} type="video/mp4" />
                          您的浏览器不支持视频播放。
                        </video>
                      )}
                      {content.content_type === "audio" && (
                        <audio controls className="w-full">
                          <source src={content.content_url} type="audio/mpeg" />
                          您的浏览器不支持音频播放。
                        </audio>
                      )}
                      {content.content_type === "image" && (
                        <img
                          src={content.content_url || "/placeholder.svg"}
                          alt={content.title}
                          className="w-full rounded-lg"
                        />
                      )}
                    </div>
                  )}

                  {content.content_body && (
                    <div className="text-gray-200 leading-relaxed whitespace-pre-wrap">{content.content_body}</div>
                  )}
                </div>
              ) : (
                <div className="text-center py-12">
                  <div className="bg-gradient-to-r from-yellow-500/10 to-orange-500/10 border border-yellow-500/30 rounded-lg p-8">
                    <h3 className="text-2xl font-semibold text-yellow-400 mb-2">付费内容</h3>
                    <p className="text-gray-300 mb-6">这是付费内容，需要购买后才能查看完整内容。</p>
                    <div className="mb-6">
                      <span className="text-3xl font-bold text-white">¥{content.price}</span>
                      <span className="text-gray-400 ml-2">起</span>
                    </div>
                    {user ? (
                      <PurchaseButton content={content} userId={user.id} />
                    ) : (
                      <Link href="/auth/login">
                        <Button className="bg-purple-600 hover:bg-purple-700 text-white">登录后购买</Button>
                      </Link>
                    )}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
