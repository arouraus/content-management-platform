import { createClient, isSupabaseConfigured } from "@/lib/supabase/server"
import { redirect } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { BookOpen, LogOut, Plus, BarChart3, Settings, Library, CreditCard } from "lucide-react"
import { signOut } from "@/lib/actions/auth"
import Link from "next/link"

export default async function DashboardPage() {
  // If Supabase is not configured, show setup message
  if (!isSupabaseConfigured) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <h1 className="text-2xl font-bold mb-4 text-white">Connect Supabase to get started</h1>
      </div>
    )
  }

  // Get the user from the server
  const supabase = createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  // If no user, redirect to login
  if (!user) {
    redirect("/auth/login")
  }

  // Get user profile and stats
  const { data: profile } = await supabase.from("user_profiles").select("*").eq("id", user.id).single()

  const { count: contentCount } = await supabase
    .from("content")
    .select("*", { count: "exact", head: true })
    .eq("author_id", user.id)

  const { count: purchaseCount } = await supabase
    .from("paid_cards")
    .select("*", { count: "exact", head: true })
    .eq("user_id", user.id)

  const { data: totalViews } = await supabase.from("content").select("view_count").eq("author_id", user.id)

  const totalViewCount = totalViews?.reduce((sum, item) => sum + item.view_count, 0) || 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/20 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-purple-400" />
            <span className="text-2xl font-bold text-white">ContentHub</span>
          </div>
          <div className="flex items-center space-x-4">
            <span className="text-gray-300">欢迎, {profile?.full_name || user.email}</span>
            <form action={signOut}>
              <Button type="submit" variant="ghost" className="text-white hover:text-purple-300">
                <LogOut className="h-4 w-4 mr-2" />
                退出
              </Button>
            </form>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">控制台</h1>
          <p className="text-gray-300">管理您的内容和查看统计数据</p>
        </div>

        {/* Quick Actions */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Link href="/content/create">
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer">
              <CardHeader className="text-center">
                <Plus className="h-12 w-12 text-purple-400 mx-auto mb-2" />
                <CardTitle className="text-white">创建内容</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-300 text-center">发布新的文章、视频或其他内容</CardDescription>
              </CardContent>
            </Card>
          </Link>

          <Link href="/library">
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer">
              <CardHeader className="text-center">
                <Library className="h-12 w-12 text-green-400 mx-auto mb-2" />
                <CardTitle className="text-white">我的内容库</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-300 text-center">查看已购买的付费内容</CardDescription>
              </CardContent>
            </Card>
          </Link>

          <Link href="/payment/history">
            <Card className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer">
              <CardHeader className="text-center">
                <CreditCard className="h-12 w-12 text-blue-400 mx-auto mb-2" />
                <CardTitle className="text-white">支付历史</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-gray-300 text-center">查看购买记录和支付详情</CardDescription>
              </CardContent>
            </Card>
          </Link>

          <Card className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer">
            <CardHeader className="text-center">
              <BarChart3 className="h-12 w-12 text-blue-400 mx-auto mb-2" />
              <CardTitle className="text-white">数据分析</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300 text-center">查看内容表现和用户互动数据</CardDescription>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10 backdrop-blur-sm hover:bg-white/10 transition-colors cursor-pointer">
            <CardHeader className="text-center">
              <Settings className="h-12 w-12 text-yellow-400 mx-auto mb-2" />
              <CardTitle className="text-white">设置</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-gray-300 text-center">配置账户和平台设置</CardDescription>
            </CardContent>
          </Card>
        </div>

        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6">
          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">总内容数</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-400">{contentCount || 0}</div>
              <p className="text-gray-400 text-sm">已发布的内容</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">总浏览量</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-400">{totalViewCount}</div>
              <p className="text-gray-400 text-sm">内容总浏览次数</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">购买内容</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-400">{purchaseCount || 0}</div>
              <p className="text-gray-400 text-sm">已购买的付费内容</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 border-white/10 backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-white">累计支出</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-yellow-400">¥{profile?.total_spent || 0}</div>
              <p className="text-gray-400 text-sm">购买内容总支出</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  )
}
