-- Enable Row Level Security on all tables
ALTER TABLE content ENABLE ROW LEVEL SECURITY;
ALTER TABLE paid_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_views ENABLE ROW LEVEL SECURITY;
ALTER TABLE content_likes ENABLE ROW LEVEL SECURITY;

-- Content policies
CREATE POLICY "Public content is viewable by everyone" ON content
  FOR SELECT USING (status = 'published');

CREATE POLICY "Users can view their own content" ON content
  FOR SELECT USING (auth.uid() = author_id);

CREATE POLICY "Users can create their own content" ON content
  FOR INSERT WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Users can update their own content" ON content
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "Users can delete their own content" ON content
  FOR DELETE USING (auth.uid() = author_id);

-- Paid cards policies
CREATE POLICY "Users can view their own paid cards" ON paid_cards
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own paid cards" ON paid_cards
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Orders policies
CREATE POLICY "Users can view their own orders" ON orders
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own orders" ON orders
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- User profiles policies
CREATE POLICY "Users can view their own profile" ON user_profiles
  FOR SELECT USING (auth.uid() = id);

CREATE POLICY "Users can update their own profile" ON user_profiles
  FOR UPDATE USING (auth.uid() = id);

CREATE POLICY "Users can insert their own profile" ON user_profiles
  FOR INSERT WITH CHECK (auth.uid() = id);

-- Content views policies
CREATE POLICY "Users can view their own content views" ON content_views
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own content views" ON content_views
  FOR INSERT WITH CHECK (auth.uid() = user_id);

-- Content likes policies
CREATE POLICY "Users can view their own content likes" ON content_likes
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Users can create their own content likes" ON content_likes
  FOR INSERT WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete their own content likes" ON content_likes
  FOR DELETE USING (auth.uid() = user_id);
