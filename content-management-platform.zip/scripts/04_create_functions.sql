-- Function to automatically create user profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.user_profiles (id, full_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NEW.raw_user_meta_data->>'avatar_url'
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to call the function when a new user signs up
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Function to update content view count
CREATE OR REPLACE FUNCTION public.increment_content_views(content_uuid UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE content 
  SET view_count = view_count + 1,
      updated_at = NOW()
  WHERE id = content_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to update content like count
CREATE OR REPLACE FUNCTION public.update_content_like_count(content_uuid UUID)
RETURNS VOID AS $$
BEGIN
  UPDATE content 
  SET like_count = (
    SELECT COUNT(*) FROM content_likes WHERE content_id = content_uuid
  ),
  updated_at = NOW()
  WHERE id = content_uuid;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to generate order number
CREATE OR REPLACE FUNCTION public.generate_order_number()
RETURNS TEXT AS $$
BEGIN
  RETURN 'ORD-' || TO_CHAR(NOW(), 'YYYYMMDD') || '-' || LPAD(FLOOR(RANDOM() * 10000)::TEXT, 4, '0');
END;
$$ LANGUAGE plpgsql;
